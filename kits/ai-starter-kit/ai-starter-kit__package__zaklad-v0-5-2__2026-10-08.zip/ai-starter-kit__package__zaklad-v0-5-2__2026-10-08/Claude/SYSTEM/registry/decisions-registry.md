---
type: registry
version: 2026-09-23
visibility: PUBLIC
status: draft
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-23

# Registr rozhodnutí

Jeden řádek na rozhodnutí. **Nejdřív řádek sem, potom soubor** (viz `project-method.md`, sekce 4). Nové ID = nejvyšší + 1. Stavy: `proposed` · `accepted` · `superseded`.

| ID | Datum | Projekt | Rozhodnutí | Stav | Soubor |
|---|---|---|---|---|---|
