---
type: registry
visibility: PUBLIC
status: live
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-10-08

# Poznámky pro autora kitu

Sem Claude s tvým souhlasem zapisuje, **co v kitu nefungovalo nebo chybělo** (ne co je o tobě). Pomůže to dalším verzím. **Nic odtud neodchází samo**: pošleš to ty, když budeš chtít, a předtím si text přečteš. Nepiš sem osobní údaje, jména jiných lidí ani obsah svých dokumentů.

Formát jedné poznámky:

```
### RRRR-MM-DD — krátký název (skill: jméno)
Co se stalo nebo co chybělo:
Co jsem čekal(a):
```

Pod poznámky se jen přidává. Až je pošleš, Claude připíše dolů řádek v sekci **Odesláno**. Neposlané poznámky jsou ty s datem po posledním takovém řádku.

## Poznámky

_(zatím žádné)_

## Odesláno

_(zatím nic)_
