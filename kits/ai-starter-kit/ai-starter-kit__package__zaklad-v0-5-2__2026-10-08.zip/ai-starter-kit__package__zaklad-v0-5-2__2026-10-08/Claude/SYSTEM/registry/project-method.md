---
type: reference
version: 2026-09-24
visibility: PUBLIC
status: draft
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-24

> **Vrstvy skillů.** Skilly jsou ve třech vrstvách: **Základ**, **Nadstavba** a **Pokročilé**. Přesný seznam a stav je v `SYSTEM/registry/skills-catalog.md`. Nemáš-li skill z vyšší vrstvy nainstalovaný, jeho práci dělá Claude jednodušeji sám, nebo se přeskočí.

# Metoda projektů

Jak se v tomhle workspace vedou projekty. Čtou ji `workspace-architect`, `project-planner`, `session-close`, `cleanup` a `catalog`. Kdyby skill tvrdil něco jiného, platí tenhle soubor.

## 1. Dva druhy projektu, dvě role

| Druh | Co to je | Příklad | Skill | Co vidí |
|---|---|---|---|---|
| `system` | něco, co existuje a mění se | aplikace, workspace, sada skillů, domácí síť | `workspace-architect` | **mapu**: co kde je, jak to visí, jaký je stav částí |
| `process` | něco, co proběhne a skončí | rekonstrukce, stěhování, plán studia | `project-planner` | **plán**: fáze, kdo je aktér, kdy se rozhoduje |

Návrh AI systému (agenti, workflow) je věc pro `ai-builder` a vždy se zapíše jako `system`.
Nikdo z nich projekt „nestaví“ sám: architekt založí kostru, project-planner řídí provedení.
Nejsi-li si jistý druhem, ptej se: *bude to existovat a měnit se, nebo to proběhne a skončí?* Smíšený případ jsou dva projekty s vazbou (`depends_on`).

## 2. Stavy

Jeden slovník pro všechno (komponenty, fáze, celé projekty):

| Stav | Význam u komponenty systému | Význam u fáze procesu |
|---|---|---|
| `draft` | navrženo, ještě nezačato | naplánováno, nezačalo |
| `wip` | rozpracováno | běží |
| `live` | funguje, používá se | hotovo |
| `dormant` | odloženo, může se vrátit | odloženo |
| `archived` | uzavřeno, jen pro záznam | uzavřeno nebo zrušeno |
| `missing` | **má existovat, ale chybí** (je v mapě nebo plánu, soubor nebo věc není) | totéž |

Stav se mění, **když se změnila skutečnost**, ne když se plánuje. Rozpracovanost = počet `live` děleno celkem.

## 3. Co se zapisuje kam

Složka projektu. Kde leží, určuje řádek `Projekty` ve `folder-map.md`: **jedna vrstva** = `PROJECTS/<projekt>/` (výchozí, doporučeno), **pod oblastí** = `AREAS/<skupina>/<oblast>/<projekt>/`. Příslušnost k oblasti je **vždy** v poli `area`, i když ji ve variantě „pod oblastí“ ukazuje i poloha složky:

| Soubor | Účel | Jak se píše |
|---|---|---|
| `brief.md` | proč projekt je, cíl, hranice, „hotovo, když…“ | jednou, mění se zřídka |
| `map.md` (systém) nebo `plan.md` (proces) | mapa nebo plán | přepisuje se, drží aktuální stav |
| `log.md` | deník | **jen se přidává na konec**, nikdy se nepřepisuje. Záznam: `## RRRR-MM-DD — název` a pár odrážek |
| `ideas.md` | nápady a úkoly zachycené k projektu cestou (zapisuje `idea-inbox`) | **jen se přidává na konec**: `- RRRR-MM-DD · věta`. Zpracuje se při RESUME, hotové se přeškrtnou nebo přenesou do plánu |
| `state.json` | strojově čitelný stav | přepisuje se (schéma níže) |
| `dashboard.html` | volitelný přehled | generuje se ze `state.json`, ručně se neupravuje |
| `decisions/` | rozhodnutí (ADR-lite) | jeden soubor na rozhodnutí |

**Pravidlo:** *stav* patří do `state.json` (přepisuje se), *co se stalo* do `log.md` (přidává se), *proč jsme se rozhodli* do `decisions/`. Nemíchej je: deník, který drží stav, se nedá číst, a stav v deníku zastará.

### Schéma `state.json`

```json
{
  "project": "rekonstrukce-kuchyne",
  "type": "system | process",
  "area": "domacnost",
  "due": "2026-12-31",
  "status": "draft | wip | live | dormant | archived",
  "updated": "2026-09-23",
  "summary": "jedna věta: kde jsme",
  "depends_on": [],
  "components": [{ "name": "", "status": "draft", "note": "" }],
  "phases": [{ "name": "", "status": "draft", "owner": "", "note": "" }],
  "open_decisions": [{ "id": "D-004", "note": "" }],
  "next_actions": [""],
  "handoff": [{ "decision": "D-007", "to": "workspace-architect", "system": "domaci-sit", "status": "open | done" }]
}
```

`components` se používá u `system`, `phases` u `process`, druhé pole zůstane prázdné (`[]`). `project` = název složky. **`area`** je oblast projektu, **musí být v seznamu „Moje oblasti“** ve `folder-map.md` (jedna oblast na projekt). **`due`** je termín (`RRRR-MM-DD`), prázdný řetězec `""`, když termín není. Projekt bez termínu a bez „hotovo, když…“ je spíš oblast než projekt; zeptej se. `note` u komponenty i fáze je volitelná poznámka nebo blokátor. `system` v `handoff` je volitelné a říká, kterého systémového projektu (složka v `PROJECTS/`) se předání týká. Neznámé pole nemaž, jen ho nech.

**`open_decisions` a ID:** otevřené rozhodnutí má vždy ID `D-…`, tedy je to řádek ve `decisions-registry.md` se stavem `proposed`. Drobnost bez ID (nestojí za zápis rozhodnutí) patří jen do `plan.md` nebo `map.md`, ne do `open_decisions`.

## 4. Rozhodnutí (ADR-lite)

**Kdy zapsat:** rozhodnutí, u kterého bys za měsíc chtěl vědět *proč*: volba mezi variantami, změna struktury, trvalý důsledek. Drobnosti ne.

**Postup (pořadí je důležité — registr PŘED souborem):**
1. Otevři `SYSTEM/registry/decisions-registry.md` a najdi nejvyšší ID. Nové je o jedna vyšší (`D-001`, `D-002`…; číslování jedno pro celý workspace).
2. Zapiš řádek do registru (sloupec **Soubor** = cesta od složky `Claude/`, třeba `PROJECTS/domaci-sit/decisions/domaci-sit__decision__router__2026-09-23.md`).
3. Teprve potom založ soubor `<složka-projektu>/decisions/<projekt>__decision__<tema>__RRRR-MM-DD.md` (rozhodnutí bez projektu jdou do `SYSTEM/registry/decisions/`).

**Šablona souboru:**

```
---
id: D-007
status: proposed | accepted | superseded
date: RRRR-MM-DD
project: <projekt>
---
# D-007 — <název rozhodnutí>
**Kontext:** proč se to řešilo.
**Rozhodnutí:** co jsme zvolili (jedna až tři věty).
**Alternativy:** co jsme zvažovali a proč ne.
**Důsledky:** co z toho plyne, co se tím uzavírá.
```

Nahrazené rozhodnutí se **nemaže**: dostane `superseded` a odkaz na nové.

## 5. Jeden přehled projektů

`SYSTEM/registry/projects-registry.md` — **jeden řádek na projekt**, detail zůstává ve složce projektu. Sloupce: `Projekt | Druh | Oblast | Stav | Poslední práce | Složka | Poznámka`. Píše ho `workspace-architect` nebo `project-planner` při založení a při změně stavu. Druh projektu (`system` / `process`) určuje, který skill ho vede. **Složka** je cesta ke složce projektu (`PROJECTS/<projekt>/` nebo `AREAS/<skupina>/<oblast>/<projekt>/`, podle řádku `Projekty`), u uzavřeného projektu `ARCHIVE/projects/<projekt>/`. Oblast v registru se musí shodovat s polem `area` ve `state.json`.

## 6. Tři kontroly konzistence (a jedna navíc)

1. **Sirotci:** projekt v registru bez složky; složka projektu (v `PROJECTS/` nebo pod oblastí, podle řádku `Projekty`) bez řádku v registru; rozhodnutí v registru bez souboru a naopak.
2. **Chybějící reference:** odkaz v `brief`, `map`, `plan`, `log` nebo `state.json` na soubor, projekt nebo ID (`D-…`), které neexistuje.
3. **Cykly:** projekt A závisí na B a B na A (pole `depends_on`), přímo nebo přes další.

Při **nepotvrzené struktuře** (`Struktura potvrzena: zatím ne`) skript přeskočí kontroly členství v seznamu „Moje oblasti“ a kontroly složek oblastí a hlásí jediné `WARN`; shoda pole `area` s registrem se kontroluje vždy. Oblasti se týká i to, že archivované projekty si `area` ponechávají, i když oblast ze seznamu zanikla.

Kontrola **`poloha`** hlídá, že projekt leží tam, kde říká zvolená varianta (`Projekty` ve `folder-map.md`), a u varianty „pod oblastí“ (**FLAG**) že se oblast v cestě shoduje s polem `area`. Složka pod oblastí je **projekt**, jen když obsahuje `state.json` nebo `brief.md`; klient nebo podsložka oblasti proto `brief.md` obsahovat nesmí.

Skript `consistency-check.py` k těmto třem kontrolám přidává čtvrtou, lehčí (**stav**): chybějící nebo neplatná pole ve `state.json`, neplatný stav, rozpracovaný projekt bez aktualizace přes 30 dní, nesoulad s registrem, **oblast projektu, která není v seznamu „Moje oblasti“ nebo se liší mezi `state.json` a registrem**, projekt s termínem v minulosti, uzavřený projekt mimo `ARCHIVE/projects/` a neuzavřený v něm, a oblast ze seznamu bez složky `AREAS/<skupina>/<oblast>/`, poloha složky projektu, která neodpovídá zvolené variantě (`Projekty`), a u varianty „pod oblastí“ oblast v cestě, která se liší od pole `area`. Kontrola vypíše nálezy a **nic neopravuje bez souhlasu**. Omezení: závislosti mezi *komponentami* jednoho systému drží sloupec „Závisí na“ v `map.md`, ne `state.json`, takže cykly na úrovni komponent kontrola nevidí (jen cykly mezi projekty přes `depends_on`). Spouští ji `workspace-architect` při navázání na projekt, `workspace-architect` napříč celým workspace a `cleanup` při úklidu.

## 7. Předání z plánu do mapy

Rozhodnutí z plánu, které mění strukturu systému, zapíše `project-planner` jako ADR-lite (řádek v registru, soubor) a přidá do `state.json` řádek v `handoff` se `status: open`. `workspace-architect` ho při navázání zapracuje do `map.md` a přepne na `done`. Protože řádek leží v souboru, který vytvořil `project-planner`, dělá to workspace-architect **jen se souhlasem uživatele** (červená linie 4: přepis souboru jiného skillu). Pole `system` říká, kterého systému se předání týká; není-li vyplněno, projde workspace-architect `handoff` všech projektů.

## 8. Uzavření projektu (archivace)

Hotový nebo opuštěný projekt se **přesune do `ARCHIVE/projects/<projekt>/`**, aby seznam aktivních projektů zůstal krátký. Dělá to `project-planner` (proces) nebo `workspace-architect` (systém) **po souhlasu uživatele**:

1. Do `log.md` projektu připiš závěrečný záznam (co se povedlo, co příště).
2. Ve `state.json` nastav `status: archived` a `updated`.
3. **Přesuň složku projektu** (kdekoli leží, `PROJECTS/<projekt>/` nebo pod oblastí) do `ARCHIVE/projects/<projekt>/` (složku `ARCHIVE/projects/` založ, chybí-li, ta je v mapě).
4. V `SYSTEM/registry/projects-registry.md` změň u řádku **Stav** na `archived` a **Složku** na `ARCHIVE/projects/<projekt>/`.
5. V `SYSTEM/registry/decisions-registry.md` přepiš ve sloupci **Soubor** cesty rozhodnutí tohoto projektu (původní cesta → `ARCHIVE/projects/…`).
6. Zkontroluj konzistenci (`consistency-check.py`). Odkazy z jiných projektů na tenhle projekt, které se přesunem rozbily, jen vypiš uživateli; oprava se dělá po souhlasu (`cleanup`, je-li nainstalován).

**Obnova:** vrátit projekt z archivu je zvláštní rozhodnutí. Dělá se po souhlasu stejnými kroky obráceně (přesun zpět na původní místo, `status` jiný než `archived`, oprava řádku v registru a cest rozhodnutí, kontrola konzistence). Sloupec **Poslední práce** se archivací nemění: zůstává datem poslední skutečné práce na projektu.

Uzavřená **oblast** (opuštěná firma, dostudovaná škola) se přesune celá do `ARCHIVE/areas/<skupina>/<oblast>/`. **Projekty oblasti** (leží v `PROJECTS/` nebo pod oblastí) se uzavřou zvlášť podle kroků 1 až 6 výše do `ARCHIVE/projects/`, po souhlasu u každého. Dělá to `cleanup` po souhlasu, včetně oprav registru. Archivované projekty si ponechávají pole `area` i po zániku oblasti ze seznamu Moje oblasti.
