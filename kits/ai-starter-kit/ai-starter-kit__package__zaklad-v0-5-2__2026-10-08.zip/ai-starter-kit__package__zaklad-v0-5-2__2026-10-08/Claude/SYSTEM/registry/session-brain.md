---
updated: RRRR-MM-DD
session: "jedna věta: co se dělalo"
---

# Předání (session-brain)

Krátká poznámka pro příští práci. Píše `session-close`, čte se jako první. Drž ji na jednu obrazovku (do ~40 řádků); starší věci patří do `log.md` projektu.

## Kde jsme
<co se dokončilo, co běží — pár vět>

## Horké projekty
- <projekt> — <stav a další krok>

## Pamatuj
- <věc, kterou by příště bylo snadné zapomenout>

## Otevřeno
- <nedořešené rozhodnutí nebo otázka>

## Next action
<první věc, kterou udělat příště>
