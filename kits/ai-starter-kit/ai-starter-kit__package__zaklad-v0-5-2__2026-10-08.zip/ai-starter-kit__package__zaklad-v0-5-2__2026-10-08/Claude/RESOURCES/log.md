---
type: log
---

# Resources — deník změn

Jen se přidává na konec, nikdy se nepřepisuje. Záznam: `## RRRR-MM-DD — co se udělalo` a odrážky (zpracovaný zdroj, nová stránka, oprava).
