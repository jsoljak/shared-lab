> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-23

# Začni tady

Pět věcí, které potřebuješ vědět. Zbytek se naučíš za pochodu.

1. **Claude vidí jen složku `Claude/`.** Všechno důležité ukládej tam, jinde to nevidí (a ty to pak nenajdeš).
2. **Poprvé napiš:** „Začínám — spusť onboarding.“ Nejdřív si spolu projdete, **jak je složka uspořádaná a jak se soubory jmenují** (to je nejdůležitější půlhodina, ať se ti nezačne hromadit bordel), potom vyplníte profil a založíte první projekt. Trvá to asi hodinu.
3. **Denně stačí tři věty:** „Napadlo mě…“ (zapíše nápad, aby nepropadl), „Chci založit projekt…“ (zeptám se jednou, jestli to bude dlouho fungovat, nebo skončí, a podle toho založím mapu, nebo plán), „Končím.“ (uloží, kde jsi skončil, ať navážeš zítra).
4. **Claude se zeptá, než něco smaže nebo založí novou složku.** Odpověz ano, nebo ne. To je pojistka, ne obtěžování.
5. **Nevkládej do chatu hesla, PIN, čísla karet ani rodná čísla.** Claude je nepotřebuje a neměly by se uložit.

## Když něco nefunguje

- Claude se chová, jako by neznal pravidla? Napiš mu: **„Přečti Claude/CLAUDE.md.“**
- Neví, co má dělat dál? Napiš: **„Kde jsem skončil?“** (přečte předání z minula).
- Nevíš, co Claude umí? Napiš: **„Jaké skilly mám?“** (ukáže seznam).
