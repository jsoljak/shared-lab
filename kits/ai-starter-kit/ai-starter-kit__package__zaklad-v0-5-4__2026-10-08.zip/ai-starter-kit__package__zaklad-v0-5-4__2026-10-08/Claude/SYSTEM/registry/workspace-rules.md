---
type: reference
version: 2026-09-23
visibility: PUBLIC
status: draft
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-23

> **Vrstvy skillů.** Skilly jsou ve třech vrstvách: **Základ**, **Nadstavba** a **Pokročilé**. Přesný seznam a stav je v `SYSTEM/registry/skills-catalog.md`. Nemáš-li skill z vyšší vrstvy nainstalovaný, jeho práci dělá Claude jednodušeji sám, nebo se přeskočí.

<!-- KIT:BEGIN pojmenovani -->
# Pravidla pojmenování a složek

Jedno místo, kde stojí, jak se v tomhle workspace **pojmenovávají soubory** a **kam se co ukládá**. `CLAUDE.md` z toho drží jednostránkový výtah, `file-guard` je vynucuje při zápisu a `cleanup` při úklidu. Kdyby se někde tvrdilo něco jiného, platí tenhle soubor.

Pravidla mají jediný účel: za rok najdeš, co jsi psal(a), a Claude to najde taky.

## 1. Jak pojmenovat soubor

```
oblast__typ__tema__RRRR-MM-DD.md
```

| Část | Co to je | Příklad |
|---|---|---|
| `oblast` | jedna z **tvých oblastí** ze seznamu „Moje oblasti“ v `folder-map.md` (nevymýšlí se za pochodu; jedinečná napříč skupinami `work`, `school`, `personal`) | `firma-a`, `domacnost`, `finance`, `zdravi` |
| `typ` | jaký druh dokumentu to je | `brief`, `plan`, `notes`, `decision`, `report`, `log` |
| `tema` | čeho se to týká, krátce | `rekonstrukce-kuchyne` |
| `datum` | kdy soubor vznikl | `2026-09-23` |

Celé: `domacnost__plan__rekonstrukce-kuchyne__2026-09-24.md`

**Technická pravidla** (kontroluje je `scripts/name-check.py` ve skillu `file-guard`):
- jen malá písmena, čísla a pomlčky; **bez diakritiky, bez mezer** (`kuchyne`, ne `Kuchyně`);
- části se oddělují dvěma podtržítky `__`, slova uvnitř části jednou pomlčkou;
- datum je vždy **na konci** ve tvaru `RRRR-MM-DD`, těsně před příponou.

*Proč:* dvě podtržítka dovolí mít v tématu pomlčky a soubory se řadí a hledají podle oblasti a typu. Datum na konci je jen pořadí vzniku.

**Doporučené typy** (`typ`): `brief` (zadání) · `plan` · `notes` (poznámky) · `decision` (rozhodnutí) · `report` · `draft` (koncept) · `list` (seznam) · `log` (deník). Nový typ je v pořádku, když žádný z nich nesedí. Nevymýšlej ale synonyma (`poznamky`, `notes`, `zapis` pro totéž).

### Dva druhy souborů: s datem a bez data

| Druh | Příklad | Datum v názvu? |
|---|---|---|
| **Výstup** — vznikne jednou a nemění se (zápis, report, plán k datu) | `domacnost__report__stav-stavby__2026-09-24.md` | **ANO** |
| **Reference nebo průběžný soubor** — přepisuje se nebo do něj přibývá, odkazují na něj jiné soubory (pravidla, deník, přehled) | `domacnost__notes__pravidla-domu.md` | **NE** — datum verze patří do záhlaví uvnitř (`version: 2026-09-23`) |

*Proč:* soubor s datem v názvu, na který odkazují jiné soubory, by se při každé aktualizaci přejmenoval a všechny odkazy by se rozbily.

### Výjimky — pevné názvy

Tyhle soubory mají stálý název, `file-guard` je nechá být: `CLAUDE.md`, `START-HERE.md`, `PROFILE.md`, `kit-version.md`, `move-log.md`, `feedback-pro-autora.md`, `ideas.md` (ve složce projektu), `index.md`, `log.md`, `README.md`, `SKILL.md`, uvnitř složky projektu `brief.md`, `plan.md`, `map.md`, `state.json`, `dashboard.html`, v `SYSTEM/skill-memory/` `lessons.md` a `voice.md` a přehledy v `SYSTEM/registry/` (`skills-catalog`, `projects-registry`, `session-brain`, `decisions-registry`, `folder-map`, `workspace-rules`, `project-method`).
Ve složce `INBOX/` stačí `RRRR-MM-DD-tema.md` (rychlý zápis). V `RESOURCES/` je název jen slug s pomlčkami (`karpathy-llm-wiki.md`).

## 2. Jak pojmenovat složku

- **velikost písmen se drží přesně** (`PROJECTS`, ne `projects`) a nezakládají se dvě složky lišící se jen velikostí písmen (na macOS a Windows by splynuly);
- malá písmena, bez diakritiky, slova spojená pomlčkou (`PROJECTS/rekonstrukce-kuchyne/`);
- **název složky projektu se nikdy nemění.** Kolem něj visí odkazy. Když ho opravdu potřebuješ změnit, nech to udělat `cleanup` (opraví odkazy);
- systémové složky (`INBOX`, `PROJECTS`, `AREAS`, `RESOURCES`, `ARCHIVE`, `SYSTEM` a v ní `registry`, `skill-memory`, `skills`) a tři skupiny oblastí (`work`, `school`, `personal`) mají anglický název a nepřejmenovávají se. Názvy **oblastí** si volí uživatel (jedno slovo, bez diakritiky, klidně česky: `domacnost`, `firma-a`).

## 3. Kam co patří (metoda PARA)

Úplná mapa je v **`SYSTEM/registry/folder-map.md`** — jediné místo, kde stojí, která složka je pro co. Řídí se tím, **co s věcí budeš dělat**, ne tím, o čem je. Čtyři hlavní složky:

| Složka | PARA | Co to je | Příklad |
|---|---|---|---|
| `PROJECTS/<projekt>/` (nebo pod oblastí, viz níže) | Projects | věc s **cílem a koncem** | rekonstrukce kuchyně, seminárka, výlet |
| `AREAS/<skupina>/<oblast>/` | Areas | **trvalá odpovědnost** bez konce | firma, domácnost, zdraví, studium |
| `RESOURCES/` | Resources | znalosti a zdroje, ke kterým se vracíš | návody, články, poznámky k tématu |
| `ARCHIVE/` | Archive | hotové a odložené věci ze všeho výše | uzavřený projekt, opuštěná firma |

Plus `INBOX/` pro rychlé zápisy a systémové složky `SYSTEM/registry/`, `SYSTEM/skill-memory/`, `SYSTEM/skills/`, o které se stará Claude.

**Zásady, které předcházejí bordelu:**
- **Projekt bez konce je oblast.** Každý projekt má „hotovo, když…“ a nejlépe termín. Nemá-li ani jedno, ptej se, jestli to není oblast.
- **Oblastí je málo:** 5 až 8 celkem. Překročíš-li to, ptej se u každé nové, jestli je to trvalá odpovědnost, nebo projekt. Oblasti se nesmějí překrývat (zkouška: *kam bys to šel hledat?*).
- **Skupina je jedna ze tří pevných složek:** `work`, `school`, `personal`. Zakládají se jen ty, které člověk opravdu má. **`school` jen pro toho, kdo sám studuje** (i vedle práce, pak je vedle `work`); jinak škola dětí patří do oblasti `skola-deti` v `personal`.
- **Klient není oblast.** Práce s koncem je projekt. Dlouhodobý klient s opakující se prací je podsložka oblasti (`AREAS/work/firma-a/klient-novak/`), jen jedna úroveň.
- **Nejvýš tři úrovně složek** uvnitř `AREAS/`. Podsložku zakládej až při zhruba 15 souborech.
- **Projekty: dvě varianty** (volí se v onboardingu, řádek `Projekty` ve `folder-map.md`). **Jedna vrstva (doporučeno):** všechny v `PROJECTS/`, název doporučeně začíná oblastí (`firma-a-relaunch-webu`); vidíš vše, co běží, na jednom místě a hotový projekt se přesune jedním krokem. **Pod oblastí:** `AREAS/<skupina>/<oblast>/<projekt>/`, příslušnost je vidět ve složkách, ale je to o úroveň hlouběji. V obou variantách má projekt pole `area`.
- **Projekt patří k jedné oblasti** (pole `area`). Patří-li ke dvěma, zvol tu, kde bys ho hledal, a druhou zmiň v popisu.
- **Hotové věci se archivují.** Uzavřený projekt jde po souhlasu do `ARCHIVE/projects/`, aby seznam projektů zůstal krátký.
- **Resources nejsou smetiště.** Drž jen to, co opravdu používáš.
- **Pracovní oblast:** dávej do ní jen to, co smíš vkládat do AI nástrojů (bez důvěrných dat firmy, klientů a kolegů). Složka tě nechrání, chrání tě jen to, co do ní vložíš.
- Nevíš kam → zeptej se `file-guard`, navrhne místo a zapíše ho do mapy.

## 4. Co se nedělá bez zeptání

Tyhle věci `file-guard` nikdy neudělá potichu:
1. smazání jakéhokoli souboru nebo složky,
2. založení nové složky, která není v `folder-map.md`,
3. zápis mimo místa v `folder-map.md`,
4. přepsání souboru, který vytvořil jiný skill,
5. změna systémových souborů (`CLAUDE.md`, `SKILL.md`, `folder-map.md`, `workspace-rules.md`).

Dočasné soubory a čtení se neptají.

*Proč:* zápis se dá vrátit jen tehdy, když víš, že k němu došlo.
<!-- KIT:END pojmenovani -->

## Moje výjimky

_Sem piš své vlastní věci. Část kitu nahoře se při aktualizaci kitu může vyměnit (po tvém souhlasu), tuhle část **nikdy**._
