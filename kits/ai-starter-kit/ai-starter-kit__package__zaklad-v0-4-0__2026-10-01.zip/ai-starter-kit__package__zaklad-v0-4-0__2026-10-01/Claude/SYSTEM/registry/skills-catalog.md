---
type: registry
version: 2026-09-23
visibility: PUBLIC
status: draft
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-23

# Katalog skillů

Lidský přehled skillů, které máš. Aplikace sama spravuje, co je nainstalováno; tenhle soubor je tvoje poznámka, k čemu který slouží a v jakém je stavu. Zatím ho vedeš ručně. Nový řádek ti přidá `skill-builder`. Stavy: `draft` (koncept) · `wip` (zkouší se) · `live` (používá se) · `dormant` · `archived`.

## Vrstvy

- **Základ:** stačí na to, abys postavil(a) cokoli, uměl(a) se rozhodnout, zadat Claudovi dobrou práci a udělat si vlastní skill. Začni tady.
- **Nadstavba:** skilly pro paměť a pořádek. Přidávají se, až Základ používáš.
- **Pokročilé:** návrh AI pomocníků a pohled napříč všemi projekty.

| Skill | Vrstva | Stav | Verze | K čemu je | Poslední změna |
|---|---|---|---|---|---|
| `onboarding` | Základ | draft | 0.4.0 | první spuštění: složka, profil, první projekt | 2026-09-23 |
| `architect` | Základ | draft | 0.4.0 | vede projekty typu systém: mapa, stav částí, „kde jsem skončil“ | 2026-09-23 |
| `planner` | Základ | draft | 0.4.0 | vede projekty typu proces: fáze, kdo je zapojen, rozhodovací body | 2026-09-23 |
| `guard` | Základ | draft | 0.4.0 | kam soubor uložit, jak ho pojmenovat, ptá se před rizikem | 2026-09-23 |
| `inbox` | Základ | draft | 0.4.0 | zachytí nápad nebo úkol do 30 sekund | 2026-09-23 |
| `session-close` | Základ | draft | 0.4.0 | konec práce: předání a záznam, kde jsi skončil | 2026-09-23 |
| `safety` | Základ | draft | 0.4.0 | co nevkládat, zálohy, kontrola složky na hesla a čísla | 2026-09-23 |
| `coach` | Základ | draft | 0.4.0 | pomůže rozhodnout se, nebo napsat dobré zadání (prompt) pro Claude | 2026-09-23 |
| `skill-builder` | Základ | draft | 0.4.0 | vytvoří, upraví a zkontroluje vlastní skill | 2026-09-23 |
| `model-advisor` | Základ | draft | 0.4.0 | poradí, na jakém modelu Claude úkol pustit, ať zbytečně nevyčerpáš limit | 2026-10-01 |

## Vlastní skilly

| Skill | Stav | Verze | K čemu je | Poslední změna |
|---|---|---|---|---|
| _(zatím žádné)_ | | | | |

_Další vrstvy (Nadstavba, Pokročilé) přijdou později._
