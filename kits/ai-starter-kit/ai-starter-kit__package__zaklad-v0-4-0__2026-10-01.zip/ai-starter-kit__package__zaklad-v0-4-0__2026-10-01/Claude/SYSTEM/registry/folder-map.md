---
type: reference
version: 2026-09-24
visibility: PUBLIC
status: draft
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-24

> **Vrstvy skillů.** Skilly zmíněné níže jsou ve třech vrstvách: **Základ** (`onboarding`, `architect`, `planner`, `guard`, `inbox`, `session-close`, `safety`, `coach`, `skill-builder`), **Nadstavba** (`wiki`, `snapshot`, `catalog`, `triage`, `cleanup`) a **Pokročilé** (`ai-builder`, `architect-pro`). Nemáš-li skill z vyšší vrstvy nainstalovaný, jeho práci dělá Claude jednodušeji sám, nebo se přeskočí.

# Mapa složek

Kanonická mapa: kam patří jaký typ věcí. `guard` ji čte při každém zápisu. Pokud něco nemá řádek, `guard` se zeptá a řádek přidá. Pravidla pojmenování jsou v `workspace-rules.md`. Všechny cesty jsou od nasdílené složky `Claude/`.

Struktura vychází z metody **PARA** (Projects, Areas, Resources, Archive): hlavní složky se řídí tím, **co s věcí budeš dělat**, ne tím, o jakém je tématu. **Pravidlo psaní: VELKÁ PÍSMENA = kostra, na kterou nesahám. malá písmena = to, co tvořím já.**

## Moje oblasti

**Struktura potvrzena:** zatím ne _(doplní `onboarding`, až spolu projdete složky, oblasti a pojmenování)_

**Projekty:** zatím nezvoleno _(doplní `onboarding`: `jedna vrstva` = všechny projekty v `PROJECTS/` (doporučeno), nebo `pod oblastí` = projekt leží v `AREAS/<skupina>/<oblast>/<projekt>/`)_

_Řádky `Struktura potvrzena` a `Projekty` zapisuje `onboarding` na konci kroku Struktura, až člověk souhlasí._

_Poznámka pro skripty: řádky `Struktura potvrzena` a `Projekty` jsou vždy jen jeden. U `Struktura potvrzena` znamená hodnota začínající „zatím ne“ nepotvrzeno, jakákoli jiná neprázdná hodnota (datum) potvrzeno. U `Projekty` platí `jedna vrstva` nebo `pod oblastí`, cokoli jiného znamená nezvoleno._

**Oblast** je trvalá odpovědnost bez konce (firma, domácnost, zdraví, studium). Každá oblast je složka `AREAS/<skupina>/<oblast>/`. **Skupina** je jedna ze tří pevných složek: `work` (práce), `school` (škola), `personal` (osobní). Oblast je zároveň první část názvu souboru (`oblast__typ__tema__datum`), proto musí být její název **jedinečný napříč skupinami**. **Každá firma je vlastní oblast** ve skupině `work` (`firma-a`, `firma-b`).

Doporučený počet je **5 až 8 oblastí celkem**. **Nová oblast se přidává jen po dohodě**, ať se nehromadí `dum`, `domov` a `bydleni` vedle sebe. Oblasti se nesmějí překrývat; zkouška: *„Kdyby se stalo X, kam bys to šel hledat?“*

| Skupina | Oblast | Co sem patří |
|---|---|---|
| _(doplní onboarding)_ | | |

## Struktura

```
Claude/
├── CLAUDE.md            ← pravidla na jednu stranu (čte se automaticky)
├── START-HERE.md        ← pět vět pro začátek
├── PROFILE.md           ← kdo jsem, na čem pracuji
│
├── INBOX/               ← rychlé zápisy, než se vytřídí
├── PROJECTS/            ← PROJECTS: věci s cílem a koncem (varianta „jedna vrstva“)
│   └── <projekt>/           brief · plan nebo map · log · state.json · dashboard.html · decisions/
├── AREAS/               ← AREAS: trvalé odpovědnosti
│   ├── work/<oblast>/       ← pracovní oblasti (firma, zaměstnání)
│   ├── school/<oblast>/     ← školní oblasti
│   └── personal/<oblast>/   ← osobní oblasti (domácnost, finance, zdraví…)
│                              (varianta „pod oblastí“: projekty leží v <oblast>/<projekt>/)
├── RESOURCES/           ← RESOURCES: znalosti a zdroje: index.md · log.md · sources/ · pages/ · snapshots/
├── ARCHIVE/             ← ARCHIVE: hotové a odložené: projects/ · areas/
└── SYSTEM/              ← vše, co spravuje Claude
    ├── registry/            ← přehledy a pravidla: skills-catalog · projects-registry · session-brain · decisions-registry · folder-map · workspace-rules · project-method
    ├── skill-memory/        ← paměť skillů (aktualizace ji nepřepíše)
    └── skills/              ← zdroje tvých vlastních skillů (vzniká až při prvním skillu, se souhlasem)
```

Zakládají se **jen skupiny a oblasti, které člověk opravdu má**. Zaměstnanec, který nestuduje, `AREAS/school/` mít nebude: školu dětí řeší oblast `skola-deti` v `personal`, vlastní občasné kurzy oblast `rozvoj`. Skupina `school` je jen pro toho, kdo sám studuje (i vedle práce).

**Dvě varianty umístění projektů** (volí se v onboardingu, zapisuje se do řádku `Projekty`):
- **Jedna vrstva (doporučeno):** všechny projekty v `PROJECTS/<projekt>/`. K oblasti patří polem `area` ve `state.json` a sloupcem Oblast v registru; název složky doporučeně začíná oblastí (`firma-a-relaunch-webu`). Výhody: vidíš vše, co běží, na jednom místě; hotový projekt se přesune jedním krokem; projekt do dvou oblastí nic neřeší.
- **Pod oblastí:** projekt leží v `AREAS/<skupina>/<oblast>/<projekt>/`, příslušnost je vidět ve složkách. Cena: o úroveň hlouběji, ztratí se jednotný seznam projektů (nahradí ho přehled od `snapshot`), projekt patřící do dvou oblastí se zařadí do jedné.

V obou variantách platí totéž: pole `area` ve `state.json` a sloupec Oblast v registru, sloupec Složka v registru říká, kde projekt leží, a hotový projekt se po souhlasu přesune do `ARCHIVE/projects/<projekt>/`.

## Kam co patří (řiď se pořadím otázek)

1. Má to **cíl a konec** (rekonstrukce, seminárka, výlet)? → projekt (`PROJECTS/<projekt>/`, nebo pod oblastí podle volby). Nemá-li to konec, je to spíš oblast.
2. Je to **trvalá odpovědnost nebo trvalá věc oblasti** (pravidla domu, seznam pojistek, poznámky k práci)? → `AREAS/<skupina>/<oblast>/`.
3. Je to **znalost nebo zdroj**, ke kterému se budeš vracet (článek, návod, poznámky k tématu)? → `RESOURCES/`.
4. Už to **nepotřebuješ mít na očích**? → `ARCHIVE/`.
5. **Nevíš** nebo je to rychlý zápis? → `INBOX/`.

## Záznamy

`<složka-projektu>` je `PROJECTS/<projekt>/` (jedna vrstva), nebo `AREAS/<skupina>/<oblast>/<projekt>/` (pod oblastí), podle řádku `Projekty`.

| Typ výstupu | Složka | Název | Spravuje |
|---|---|---|---|
| Rychlý nápad, úkol | `INBOX/` | `RRRR-MM-DD-tema.md` | `inbox` |
| Vyřízené položky z inboxu | `INBOX/hotovo/` | původní název | `triage` (po souhlasu) |
| Trvalá věc oblasti | `AREAS/<skupina>/<oblast>/` | `oblast__typ__tema__RRRR-MM-DD.md` (referenci bez data) | ty / skill |
| Dlouhodobý klient v oblasti (jen jedna úroveň) | `AREAS/<skupina>/<oblast>/<klient>/` | stejné názvy | ty |
| Zadání projektu | `<složka-projektu>` | `brief.md` | `architect` / `planner` |
| Plán projektu (fáze, kdo, rozhodnutí) | `<složka-projektu>` | `plan.md` | `planner` |
| Mapa systému (struktura, stav komponent) | `<složka-projektu>` | `map.md` | `architect` |
| Deník projektu (jen se přidává na konec) | `<složka-projektu>` | `log.md` | `session-close` |
| Stav projektu | `<složka-projektu>` | `state.json` | `architect` / `planner` (při zavření práce i `session-close`: `updated`, `summary`, `next_actions` a stav částí nebo fází, u kterých se skutečnost změnila) |
| Ostatní výstup projektu | `<složka-projektu>` | `oblast__typ__tema__RRRR-MM-DD.md` | ty / skill |
| Rozhodnutí projektu (ADR-lite) | `<složka-projektu>decisions/` | `<projekt>__decision__<tema>__RRRR-MM-DD.md` | `architect` / `planner` |
| Rozhodnutí mimo projekt | `SYSTEM/registry/decisions/` | `oblast__decision__<tema>__RRRR-MM-DD.md` | `architect-pro` / ty |
| Zdroj znalostí | `RESOURCES/sources/` | slug s pomlčkami | `wiki` |
| Zpracovaná znalost | `RESOURCES/pages/` | slug s pomlčkami | `wiki` |
| Přehled stavu (snapshot) | `RESOURCES/snapshots/` | slug s pomlčkami | `snapshot` |
| Uzavřený projekt | `ARCHIVE/projects/<projekt>/` | beze změny | `planner` / `architect` (po souhlasu), `cleanup` |
| Uzavřená oblast | `ARCHIVE/areas/<skupina>/<oblast>/` | beze změny | `cleanup` (po souhlasu) |
| Registr rozhodnutí, projektů | `SYSTEM/registry/` | `decisions-registry.md`, `projects-registry.md` | `architect` / `planner` (při zavření práce i `session-close`: jen řádek Stav a Poslední práce) |
| Katalog skillů | `SYSTEM/registry/` | `skills-catalog.md` | `catalog` / `skill-builder` |
| Metoda projektů, pravidla | `SYSTEM/registry/` | `project-method.md`, `workspace-rules.md` | jen se čtou |
| Konec dne, předání | `SYSTEM/registry/` | `session-brain.md` | `session-close` |
| Paměť skillů | `SYSTEM/skill-memory/<skill>/` | `lessons.md`, `voice.md` | skill (jen připisuje) |
| Zdroje vlastních skillů | `SYSTEM/skills/<skill>/` | `SKILL.md` a další | `skill-builder` |

Poznámka: `snapshot` po vygenerování přehledu přidá **jeden řádek** do `RESOURCES/index.md` (sekce Přehledy) a záznam na konec `RESOURCES/log.md`. Jinak se v souborech skillu `wiki` nic nemění.

## Zastaralé cesty

| Stará cesta | Nová cesta | Od kdy | Poznámka |
|---|---|---|---|
| _(žádné — přidej sem, když přesouváš složku)_ | | | |

**Starý formát složek** (verze 0.2.0: `Registry/`, `wiki/`, `profile.md`, malé `projects/` a `inbox/`) se převádí samostatným souborem **`OPRAVA…md`**, ne ručně a ne skillem.

## Aktualizace mapy

- Potvrdíš nové místo pro nový druh věcí → přidej řádek do tabulky výše.
- Přesuneš složku → přidej řádek do „Zastaralé cesty“, ať `guard` ví, že stará cesta už neplatí. (Přesun hotového projektu do `ARCHIVE/` se sem nezapisuje, má pevné pravidlo výše.)
- Složka pod oblastí je **projekt**, jen když v ní leží `state.json` nebo `brief.md`. Klient nebo podsložka oblasti soubor `brief.md` nemá.
- Nová oblast → přidej řádek do tabulky „Moje oblasti“ (po dohodě) a založ složku `AREAS/<skupina>/<oblast>/`.
