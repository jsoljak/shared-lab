---
type: registry
version: 2026-09-24
visibility: PUBLIC
status: draft
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-24

# Registr projektů

Jeden řádek na projekt. Detail je ve složce projektu (`PROJECTS/<projekt>/`, u uzavřeného `ARCHIVE/projects/<projekt>/`). Píše `architect` nebo `planner` (viz `project-method.md`). Stavy: `draft` · `wip` · `live` · `dormant` · `archived`. Druh: `system` nebo `process`.

| Projekt | Druh | Oblast | Stav | Poslední práce | Složka | Poznámka |
|---|---|---|---|---|---|---|
