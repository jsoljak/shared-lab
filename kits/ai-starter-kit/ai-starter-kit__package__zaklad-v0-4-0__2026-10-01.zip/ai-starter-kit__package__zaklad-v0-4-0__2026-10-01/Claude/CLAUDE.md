> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-23

# Pravidla této složky

Tuhle složku (`Claude/`) mi nasdílel(a) uživatel jako pracovní prostor. Pracuji **jen v ní**. Tento soubor se čte na začátku každé práce. Mění se jen po dohodě s uživatelem.

## Začátek práce

1. Pokud existuje `SYSTEM/registry/session-brain.md`, přečti ho: je to krátké předání z minula.
2. Pokud existuje `PROFILE.md`, přečti ho: kdo uživatel je a na čem pracuje.
3. Otevři `SYSTEM/registry/folder-map.md` a podívej se jen na sekci **Moje oblasti**. Je-li tam **„Struktura potvrzena: zatím ne“**, onboarding ještě neproběhl. **Než založíš cokoli** (projekt, složku, soubor s vlastním názvem), nabídni skill `onboarding`: nejdřív se spolu projde struktura složek, mapa a pojmenování. Rychlý zápis do `INBOX/` a čtení smí být i dřív.
4. Nic dalšího nečti předem. Ptá-li se uživatel na projekt, najdi jeho složku podle sloupce Složka v `SYSTEM/registry/projects-registry.md` (`PROJECTS/<projekt>/` nebo pod oblastí, podle řádku `Projekty` v mapě složek) a přečti `state.json` a `log.md`.

## Kam co patří a jak se to jmenuje

- **Kam:** úplná mapa je v `SYSTEM/registry/folder-map.md` (řiď se pořadím otázek v sekci „Kam co patří“: projekt, oblast, znalost, archiv, inbox). Nevymýšlej složky z hlavy.
- **Jak pojmenovat:** `oblast__typ__tema__RRRR-MM-DD.md` (malá písmena, bez diakritiky, bez mezer, datum na konci). Reference a průběžné soubory (na které se odkazuje nebo do kterých se přidává) jsou **bez data** v názvu. Celá pravidla: `SYSTEM/registry/workspace-rules.md`.
- **Před každým zápisem, přesunem nebo mazáním** spusť skill `guard`, pokud je nainstalovaný. Pokud ne, řiď se pravidly níže sám.

## Ptej se vždy, než něco uděláš

1. **smažeš** soubor nebo složku,
2. založíš **novou složku**, která není v `SYSTEM/registry/folder-map.md`,
3. zapíšeš **mimo místa v mapě**,
4. přepíšeš soubor, který vytvořil **jiný skill**,
5. změníš systémový soubor (`CLAUDE.md`, `SKILL.md`, `folder-map.md`, `workspace-rules.md`).

Zeptej se jednou větou: co, kam, proč. Bez "ano" nic z toho nedělej. Čtení a dočasné soubory (`/tmp/`, `/sessions/`) se neptají. Po každém zápisu řekni jednou větou, co a kam jsi zapsal.

## Když nemáš přístup k souboru

- Chyba `EPERM` neznamená, že soubor neexistuje, jen že k němu nemáš oprávnění. Zkus to přes bash s cestou `/sessions/.../mnt/`.
- Chyba "outside connected folders": požádej uživatele o přístup do té složky (`request_cowork_directory`).
- Teprve když nenajdeš soubor ani pak, řekni, že neexistuje.
- **Nikdy neukládej důležité věci do `/tmp/`.** Uživatel je neuvidí a zmizí. Nemáš-li přístup do `Claude/`, řekni to a počkej.

## Práce s projekty

- Cokoli, co má víc kroků a **cíl s koncem**, dostane složku projektu (`PROJECTS/<projekt>/`, nebo pod oblastí, podle volby v mapě složek). Každý projekt patří do **jedné oblasti** ze seznamu „Moje oblasti“ (pole `area`) a má „hotovo, když…“ nebo termín; bez konce je to spíš oblast. Hotový projekt se po souhlasu přesune do `ARCHIVE/projects/`.
- **Systém, věc se strukturou** (aplikace, workspace, sada skillů) → skill `architect` (mapa: co kde je a jak to visí).
- **Postup, proces, životní projekt** (stavba, stěhování, plán) → skill `planner` (plán: fáze, kdo, rozhodovací body).
- Po podstatné práci na projektu (padlo rozhodnutí, vznikl výstup, změnil se stav) **sám zapiš** stručně do `log.md` a `state.json` a řekni jednou větou co. (Skill `session-close` dělá totéž při zavření práce a duplicitní záznam nepřidá.) Uživatel nemusí říkat "ulož".
- Rozhodnutí, která mění architekturu, zapisuj do `SYSTEM/registry/decisions-registry.md` (nejdřív řádek v registru, potom soubor).

## Rychlé zápisy a konec dne

- "Napadlo mě…", "musím nezapomenout…" → skill `inbox` (soubor do `INBOX/`, do 30 sekund).
- Uživatel končí, nebo se práce zastavila → nabídni `session-close` (předání do `SYSTEM/registry/session-brain.md`).
- Seznam nainstalovaných skillů: `SYSTEM/registry/skills-catalog.md`.
- Před velkým úkolem (přestavba mnoha souborů, dlouhá práce) nebo když uživatel řeší limit, nabídni jednou větou skill `model-advisor` (na jakém modelu to pustit). U běžné práce o modelu nemluv.

## Bezpečnost

Nevkládej do chatu ani do souborů **hesla, PIN, čísla platebních karet, rodná čísla ani skenované doklady**. Uvidíš-li je, upozorni uživatele a nekopíruj je dál. Cizí osobní údaje (zdraví, děti, finance) piš jen tak, jak je uživatel výslovně chce mít uložené.

## Jak spolupracovat

- **Česky**, pokud uživatel nepíše anglicky.
- Když si nejsi jistý, zeptej se **jednou** otázkou. Nezasypávej ho dotazy.
- Nevymýšlej názvy složek, souborů ani skillů. Nejasné navrhni ve dvou až třech variantách a nech vybrat.
- Než řekneš "to neexistuje" nebo "to nemáme", přečti si relevantní soubor. Nejdřív se podívej, potom tvrď.
- Řekni pravdu i o chybě: pokud se test nepovedl nebo krok byl přeskočen, řekni to.
