---
type: profile
updated: RRRR-MM-DD
---

# Profil

Vyplní se při onboardingu (`onboarding`) a čte se na začátku každé práce. Piš tak, jak bys to řekl(a) kamarádovi. Cokoli nechceš sdílet nech prázdné.

## Kdo jsem
- Jméno nebo přezdívka: [doplň]
- Čím se zabývám (práce, škola, domácnost): [doplň]

## Na čem teď pracuji
- [doplň — jeden až tři projekty nebo cíle]

## Co od Claude chci
- [doplň — s čím chci pomáhat: plánování, psaní, učení, rozhodování…]

## Jak se mnou mluvit
- Jazyk: čeština
- Styl (stručně/podrobně, formálně/uvolněně): [doplň]

## Co nechci
- [doplň — témata, věci, které Claude nemá dělat]

## Důležité omezení
- [doplň — čas, zdraví, děti, práce na směny… cokoli, co má Claude brát v úvahu]
