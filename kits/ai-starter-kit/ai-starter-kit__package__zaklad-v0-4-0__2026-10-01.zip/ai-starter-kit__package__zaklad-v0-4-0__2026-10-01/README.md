> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-10-01

# AI Starter Kit — Základ

Startovní sada pro práci s Claudem v desktopové aplikaci (Cowork) pro lidi, kteří nejsou AI-kovaní. **Tohle je první vrstva, Základ: 10 skillů**, které stačí na to, abys postavil(a) cokoli (systém, proces nebo osobní projekt), uměl(a) se rozhodnout, zadat Claudovi dobrou práci a udělal(a) si vlastní skill. Další vrstvy (Nadstavba a Pokročilé) přijdou později.

Sada **ještě nebyla zkoušena na cizím účtu**. Skilly, jejich skripty i šablona byly zkontrolovány mimo aplikaci. Jestli se v aplikaci nainstalují a chovají se dobře, ukáže první asistovaná session. Postup je v `RUNBOOK.md`.

## Co je uvnitř

```
ai-starter-kit (balíček)/
├── README.md                ← tento soubor
├── RUNBOOK.md               ← postup asistované session (pro toho, kdo sadu předává)
├── ai-starter-kit.plugin    ← 10 skillů najednou (hlavní cesta instalace)
├── skills-jednotlive/       ← totéž po jednom jako .skill (záložní cesta, když .plugin nejde)
└── Claude/                  ← šablona pracovní složky (zkopírovat uživateli do Dokumentů)
    ├── CLAUDE.md · START-HERE.md · PROFILE.md      ← pravidla, pět vět, profil (kořen)
    ├── INBOX/               ← rychlé zápisy
    ├── PROJECTS/            ← věci s cílem a koncem (Projects)
    ├── AREAS/               ← trvalé oblasti (Areas); skupiny work · school · personal vzniknou při onboardingu
    ├── RESOURCES/           ← znalosti a zdroje (Resources)
    ├── ARCHIVE/             ← hotové a odložené (Archive)
    └── SYSTEM/              ← vše, co spravuje Claude
        ├── registry/            ← folder-map, workspace-rules, project-method, projects-registry,
        │                          decisions-registry, skills-catalog, session-brain
        ├── skill-memory/        ← paměť skillů
        └── skills/              ← zdroje vlastních skillů (vznikne až později)
```

**Pravidlo psaní:** VELKÁ PÍSMENA = kostra, na kterou nesahám. malá písmena = to, co tvořím. Projekty si člověk při onboardingu zvolí buď v jedné vrstvě (`PROJECTS/`, doporučeno), nebo pod oblastí.

**Už jsi dostal starší verzi (0.2.0)?** Pro ty, kdo mají složku ze starého balíčku, existuje samostatný soubor `OPRAVA…md`. Bez instalace: člověk ho dá Claudovi a ten mu složku zazálohuje, uklidí a převede na tuhle strukturu.

## Deset skillů Základu

| Skill | K čemu |
|---|---|
| `onboarding` | první spuštění: **nejdřív složky, mapa a pojmenování**, potom profil a první projekt |
| `architect` | projekty typu systém: mapa, stav částí, „kde jsem skončil“ |
| `planner` | projekty typu proces: fáze, kdo je zapojen, rozhodovací body |
| `guard` | kam soubor uložit, jak ho pojmenovat (i podle tvých oblastí), ptá se před rizikem |
| `inbox` | zachytí nápad nebo úkol do 30 sekund |
| `session-close` | konec práce: předání, kde jsi skončil |
| `safety` | co nevkládat, zálohy, kontrola složky na hesla a čísla karet |
| `coach` | pomůže rozhodnout se, nebo napsat dobré zadání (prompt) pro Claude |
| `skill-builder` | vytvoří, upraví a zkontroluje tvůj vlastní skill podle pravidel kvalitního návrhu |
| `model-advisor` | poradí, na jakém modelu Claude (Haiku, Sonnet, Opus) úkol pustit, ať zbytečně nevyčerpáš limit předplatného |

Skilly z dalších vrstev (`wiki`, `snapshot`, `catalog`, `triage`, `cleanup`, `ai-builder`, `architect-pro`) jsou v některých dokumentech zmíněny. Dokud je nemáš, jejich práci dělá Claude jednodušeji sám, nebo se přeskočí.

## Nasazení ve zkratce

1. Zkopíruj složku `Claude/` uživateli do `Dokumenty/` a nasdílej ji v aplikaci jako pracovní prostor.
2. Nainstaluj `ai-starter-kit.plugin` (klik na soubor v aplikaci). Nejde-li to, nainstaluj `.skill` soubory ze složky `skills-jednotlive/` po jednom.
3. Napiš Claudovi: **„Začínám — spusť onboarding.“** První, co spolu uděláte, je **struktura**: Claude se vás nejdřív empaticky zeptá na váš běžný týden a **navrhne hotovou kostru oblastí** (pracující, student, podnikatel, jiné), kterou si upravíte. Pak projdete složky (metoda PARA), mapu a pojmenování souborů. Až potom profil a první projekt. Bez toho by se soubory zakládaly každý jinak a vznikl by bordel.

Podrobný postup s minutami, co sledovat a co dělat, když něco nejde, je v `RUNBOOK.md`.

## Známá omezení

- V aplikaci nejsou hooky ani git: `guard` nemá technické právo veta. Pravidla drží `CLAUDE.md` a skilly, a jen když se jimi Claude řídí.
- Skripty (kontrola názvů, konzistence, hesel, přehledy) vyžadují Python 3 a bash. Nejsou-li k dispozici, skilly přejdou na ruční postup a řeknou to.
- Instalovatelnost `.plugin` a načtení `CLAUDE.md` na cizím účtu jsou neověřené.
- Testovací věty skillů (`evals/`) v balíčku nejsou, byly to pracovní zkoušky autora.
