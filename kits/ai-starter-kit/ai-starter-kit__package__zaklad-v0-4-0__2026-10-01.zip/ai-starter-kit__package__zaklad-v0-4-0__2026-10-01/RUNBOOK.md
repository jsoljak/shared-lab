> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-09-23

# Runbook — asistovaná session (Základ), asi 75 minut

Pro toho, kdo sadu předává. Uživateli se nedává: je to tvůj postup a zápisník. **První session je zároveň zkouška**: nikdo zatím neověřil, že se sada na cizím účtu chová podle očekávání, a právě to zjišťuješ.

## Cíl session (podle čeho poznáš úspěch)

1. Uživatel má po session **domluvenou strukturu (složky, oblasti, pojmenování) a první projekt**.
2. **Příští den** dokáže na větu „Kde jsem skončil?“ dostat správnou odpověď.
3. Ukládá a pojmenovává soubory podle pravidel, **aniž je čte** (hlídá to `guard`). Proto je **struktura první věc**, kterou se s ním dělá: bez ní se soubory zakládají každý jinak a vznikne bordel.
4. Chápe, že si s Základem může postavit **cokoli**: systém, proces i osobní projekt.

## Než začneš (den předem, ~15 minut)

- Ověř, že má uživatel **desktopovou aplikaci Claude (Cowork)** a přihlášený osobní plán. Zapiš si verzi aplikace, může být důležitá.
- Balíček rozbal a zkopíruj na médium. **Balíček neobsahuje nic osobního**; profil se vyplňuje až u uživatele a zůstává u něj.
- Nejlépe si postup jednou projdi na svém druhém, čistém účtu nebo profilu. Když něco nejde, dozvíš se to dřív než před uživatelem.
- Řekni uživateli, ať si připraví: jeden **skutečný projekt**, který ho zajímá (rekonstrukce, výlet, učení, drobný byznys, cokoli). Na něm se onboarding učí nejlépe.

## Průběh po minutách

| Čas | Co děláš | Ověř / všimni si |
|---|---|---|
| 0–10 | Zkopíruj `Claude/` do `Dokumenty/`. V aplikaci otevři nové vlákno a nasdílej složku jako pracovní prostor. | Vidí Claude složku? (Zeptej se: „Co vidíš ve složce?“) |
| 10–15 | **Zkouška `CLAUDE.md`.** Zeptej se: „Jaká pravidla platí v této složce?“ | Načetl se sám? Když ne, napiš „Přečti Claude/CLAUDE.md.“ a **poznamenej si, že se nenačetl**. |
| 15–25 | Nainstaluj `ai-starter-kit.plugin` (klik na soubor). Zeptej se: „Jaké skilly mám?“ | Je jich deset? Které chybí? Když `.plugin` nejde, instaluj `.skill` po jednom ze `skills-jednotlive/`. |
| 25–45 | Napiš: **„Začínám — spusť onboarding.“** Nech Clauda vést. **První je struktura (asi 25 minut):** čtyři věty o složkách (PARA), základní složky, **empatický rozhovor o běžném týdnu a hotový návrh kostry oblastí** (pracující / student / podnikatel / jiné, 5 až 8 oblastí ve skupinách `work`, `school`, `personal`), pojmenování souborů procvičené na dvou skutečných souborech, potvrzení. Neradíš, jen sleduj. | Rozumí uživatel navrženým oblastem, nebo jich chce mnoho a překrývají se? Zeptal se ho Claude na týden a život, ne rovnou „jaké máte oblasti“? Zvládl pojmenovat dva soubory správně (bez diakritiky, s oblastí, datum na konci)? Zapsala se do `SYSTEM/registry/folder-map.md` tabulka „Moje oblasti“ (Skupina | Oblast) a **datum u „Struktura potvrzena“**? Vznikly složky `AREAS/<skupina>/<oblast>/`? Kde se zasekl? |
| 45–65 | Pokračuje onboarding: profil, pět vět, **první projekt**. | Před strukturou **nezaložil** projekt? Je název složky projektu podle pravidel? |
| 65–72 | Ať uživatel sám zkusí: „Napadlo mě…“ (`inbox`) a „Kde jsem skončil?“ | Zvládl to bez tvé nápovědy? Ptá se `guard` před novou složkou nebo smazáním? |
| 72–75 | Ať napíše: „Končím.“ (`session-close`). Vysvětli, že zítra na „Kde jsem skončil?“ navážou. | Zapsal se `SYSTEM/registry/session-brain.md`? |

**Struktura je podmínka pro projekty.** Kdyby chtěl uživatel „rovnou založit projekt“, Claude by měl vysvětlit proč ne hned a projít strukturu. Když ne, poznamenej to: je to slabé místo.

## Když něco nejde

| Příznak | Co dělat |
|---|---|
| `CLAUDE.md` se nenačte | Řekni „Přečti Claude/CLAUDE.md“, poznamenej. Bez toho pravidla neplatí (`guard` nemá jiný způsob vynucení). |
| `.plugin` se nenainstaluje | Použij `.skill` soubory po jednom. Poznamenej, co aplikace hlásila. |
| Skript nejde spustit (chybí Python nebo bash) | Skill přejde na ruční postup a řekne to. Poznamenej, kterého skriptu se to týkalo. |
| Uživatel oblasti nechápe nebo jich chce deset | Vrať se k otázce „Jaké velké oblasti má tvůj život nebo práce?“ Stačí tři. Nová oblast jde přidat později, ale jen po dohodě. |
| Claude po onboardingu neví, kde jsi skončil | Zkontroluj, jestli existuje `SYSTEM/registry/session-brain.md` a co obsahuje. Poznamenej. |
| Uživatel se ztratí | Nevysvětluj skill. Vrať ho k pěti větám ze `START-HERE.md`. |

## Den poté (2 minuty, zpráva nebo telefon)

1. Napsal(a) „Kde jsem skončil?“ a odpověď seděla?
2. Zeptal se `guard` na něco (smazání, nová složka)?
3. Co ho zaskočilo nebo zdrželo?

## Co neslibovat

- **Nadstavbu a Pokročilé** (znalostní báze, přehledy, koučování, tvorba vlastních skillů) — přijdou později.
- Že je to bez chyb. Je to první zkouška.
- Že je to záloha. `safety` doporučí zálohu složky `Claude/`, ale nedělá ji.

## Po session (ty)

Zapiš, jak dopadl každý bod zkoušky (`CLAUDE.md` načten / plugin nainstalován / **struktura domluvena a pojmenování zvládnuto** / onboarding dokončen / příští den správně / skripty běží), a co je třeba změnit. Vyhodnocení pak jde do evidence projektu a určí, co se opraví před další distribucí.

## Soukromí

Profil a projekty uživatele patří jemu. Do sady se nekopírují a bez jeho souhlasu je nikam neposílej.
