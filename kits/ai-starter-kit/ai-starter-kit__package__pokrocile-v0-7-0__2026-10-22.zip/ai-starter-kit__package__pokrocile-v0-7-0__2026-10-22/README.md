> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-10-22

# AI Starter Kit — Pokročilé

**Rozšíření Základu.** Základ (13 skillů) stačí na to, abys postavil(a) cokoli, vedl(a) projekty, rozhodoval(a) se a udělal(a) si vlastní skill. Pokročilé přidávají skilly pro chvíli, kdy ti Základ začne být těsný: máš víc projektů najednou, víc věcí na sebe čeká a chceš mít přehled bez vlastního tabulkového systému.

**Potřebuješ nainstalovaný Základ** (složku `Claude/` s mapou a pravidly a jeho skilly). Pokročilé skilly na něm stojí a bez něj neví, kde co leží. Základ najdeš na [úvodní stránce](https://github.com/jsoljak/shared-lab/blob/main/kits/ai-starter-kit/README.md).

**Nic nespěchá.** Každý skill tady má řádek **Kdy ho ještě nepotřebuješ**. Když se v něm poznáš, zůstaň u Základu: přidaný skill je přidaná práce.

## Co Pokročilé přidávají

| Skill | Rozšiřuje (Základ) | Co Základ už umí | Co přidává | Kdy ho potřebuješ | Kdy ho ještě nepotřebuješ |
|---|---|---|---|---|---|
| `work-graph` | `project-planner`, `workspace-architect` | plán jednoho projektu (fáze, kdo, rozhodnutí) a mapu jednoho systému; závislosti mezi celými projekty | **graf práce napříč projekty:** jednotlivé kroky, kdo je drží a na co čekají, i když je čekání v jiném projektu. Skript řekne, co můžeš dělat hned a co blokuje nejvíc dalších věcí. Před každým zápisem zálohuje, nic nemaže. | máš tři a víc běžících projektů a ztrácíš přehled, co čeká na co („koupelna čeká na rozpočet, rozpočet na nabídku“) | máš jeden nebo dva projekty; plán projektu ti stačí |

Další skilly sem budou přibývat. Každý dostane řádek ve stejné tabulce: co v Základu rozšiřuje, co přidává a kdy ho ještě nepotřebuješ.

**Ve stejné verzi dostal i Základ** (`workspace-architect`) volitelný **plný zápis rozhodnutí**: u drahého nebo těžko vratného rozhodnutí nabídne delší tvar s měřítky, tabulkou variant a podmínkou, kdy to otevřít znovu. Krátký zápis zůstává výchozí.

## Instalace

1. Máš Základ ve verzi 0.7.0? Starší aktualizuj podle [úvodní stránky](https://github.com/jsoljak/shared-lab/blob/main/kits/ai-starter-kit/README.md#aktualizace) (napiš Claudovi „Aktualizuj kit.“).
2. Stáhni a rozbal balíček Pokročilé. Otevři `ai-starter-kit-pokrocile.plugin` (má jiné jméno než plugin Základu, takže ho nepřepíše). Nejde-li to, nainstaluj `.skill` ze složky `skills-jednotlive/` po jednom. Můžeš si vzít i jen jeden skill.
3. Napiš Claudovi větu ze sloupce níže. Při prvním použití se skill zeptá, než založí svůj soubor.

| Skill | Řekni třeba | Co vznikne |
|---|---|---|
| `work-graph` | „Přidej do grafu: objednat obkladače, až vybereme dlaždice.“ · „Co je volné?“ · „Na čem to stojí?“ · „N-004 je hotové.“ · „Zkontroluj graf.“ | `SYSTEM/registry/work-graph.md` (jedna tabulka kroků) a zálohy v `SYSTEM/backups/work-graph/` |

## Chceš všechno anglicky?

Kit je česky. V Základu 0.7.0 umí `onboarding` převést profil, úvodní soubor a skilly do angličtiny: napiš **„Chci všechno anglicky“** (nebo „Switch everything to English“). Claude nejdřív ukáže, co převede a co záměrně ne (soubory, které čtou skripty), všechno zazálohuje a anglické verze skillů ti připraví k instalaci. Pokročilé skilly převede stejně. Po každé aktualizaci kitu se převod nabídne znovu sám, protože aktualizace vrátí české verze skillů.

## Poctivě

Je to koncept. Skilly a skripty jsou zkontrolované mimo aplikaci, na cizím účtu a na Windows zatím zkoušené nebyly. Co nefunguje, napiš mi na LinkedIn.

## Co je v balíčku

| Část | K čemu |
|---|---|
| `ai-starter-kit-pokrocile.plugin` | všechny skilly Pokročilé najednou |
| `skills-jednotlive/` | totéž po jednom jako `.skill` |
| `README.md`, `RELEASE-NOTES.md` | tenhle popis, co je nového |

Šablona složky `Claude/` v tomhle balíčku není: Pokročilé se instalují do složky, kterou už máš ze Základu.
