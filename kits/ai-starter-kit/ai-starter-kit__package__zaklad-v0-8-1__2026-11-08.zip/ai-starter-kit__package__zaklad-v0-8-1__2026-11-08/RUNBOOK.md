> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-11-08

# Runbook — asistovaná session (Základ), asi 75 minut

Pro toho, kdo sadu předává. Uživateli se nedává: je to tvůj postup a zápisník. **První session je zároveň zkouška**: nikdo zatím neověřil, že se sada na cizím účtu chová podle očekávání, a právě to zjišťuješ.

## Cíl session (podle čeho poznáš úspěch)

1. Uživatel má po session **domluvenou strukturu (složky, oblasti, pojmenování) a první projekt**.
2. **Příští den** dokáže na větu „Kde jsem skončil?“ dostat správnou odpověď.
3. Ukládá a pojmenovává soubory podle pravidel, **aniž je čte** (hlídá to `file-guard`). Proto je **struktura první věc**, kterou se s ním dělá: bez ní se soubory zakládají každý jinak a vznikne bordel.
4. Chápe, že si s Základem může postavit **cokoli**: systém, proces i osobní projekt.

## Než začneš (den předem, ~15 minut)

- Ověř, že má uživatel **desktopovou aplikaci Claude (Cowork)** staženou z **claude.ai/download** (ne z App Storu ani odjinud) a přihlášený osobní plán. Zapiš si verzi aplikace, může být důležitá. Počítač s 8 GB paměti RAM stačí.
- Balíček rozbal a zkopíruj na médium. **Balíček neobsahuje nic osobního**; profil se vyplňuje až u uživatele a zůstává u něj.
- Nejlépe si postup jednou projdi na svém druhém, čistém účtu nebo profilu. Když něco nejde, dozvíš se to dřív než před uživatelem.
- Řekni uživateli, ať si připraví: jeden **skutečný projekt**, který ho zajímá (rekonstrukce, výlet, učení, drobný byznys, cokoli). Na něm se onboarding učí nejlépe.

## Průběh po minutách

| Čas | Co děláš | Ověř / všimni si |
|---|---|---|
| 0–10 | Zjisti, jestli má Mac, nebo Windows (onboarding se na to zeptá sám; Windows: přípony souborů zapnout hned). Zkopíruj `Claude/` do `Dokumenty/`. V aplikaci otevři nové vlákno a nasdílej složku jako pracovní prostor. | Vidí Claude složku? (Zeptej se: „Co vidíš ve složce?“) |
| 10–15 | **Zkouška `CLAUDE.md`.** Zeptej se: „Jaká pravidla platí v této složce?“ | Načetl se sám? Když ne, napiš „Přečti Claude/CLAUDE.md.“ a **poznamenej si, že se nenačetl**. |
| 15–25 | Ať uživatel sám nahraje plugin: v aplikaci vlevo **Customize** → **Plugins** → **Add** → **Upload plugin** → `ai-starter-kit.plugin` ze Stažených. **Ne do okna chatu.** Pak ať napíše: „Jaké skilly mám?“ | Našel Customize a Upload sám podle README? Jak se tlačítka jmenovala (zapiš přesně)? Vzala aplikace `.plugin`, nebo bylo nutné přejmenovat na `.zip`? Je skillů třináct? Nejde-li plugin, `.skill` po jednom: **Customize** → **Skills** → **Upload skill**. |
| 25–30 | Napiš: **„Začínám — spusť onboarding.“** Nech Clauda vést. Po otázce na Mac nebo Windows a umístění složky přijde **krok 1d Nastavení soukromí**: Claude ukáže v Settings učení modelů na chatech, paměť aplikace a konektory. Rozhoduje uživatel, ty neradíš. | Ukázal Claude správná místa v nastavení (názvy se mohou lišit podle verze aplikace)? Zapsal se do `PROFILE.md` řádek `Soukromí:`? Na Macu s iCloudem: řekl Claude „Vždy ponechat na tomto zařízení“ a že iCloud není záloha? |
| 30–45 | **Pak struktura:** čtyři věty o složkách (PARA), základní složky, **empatický rozhovor o běžném týdnu a hotový návrh kostry oblastí** (pracující / student / podnikatel / jiné, 5 až 8 oblastí ve skupinách `work`, `school`, `personal`), pojmenování souborů procvičené na dvou skutečných souborech, potvrzení. Neradíš, jen sleduj. | Rozumí uživatel navrženým oblastem, nebo jich chce mnoho a překrývají se? Zeptal se ho Claude na týden a život, ne rovnou „jaké máte oblasti“? Zvládl pojmenovat dva soubory správně (bez diakritiky, s oblastí, datum na konci)? Zapsala se do `SYSTEM/registry/folder-map.md` tabulka „Moje oblasti“ (Skupina | Oblast) a **datum u „Struktura potvrzena“**? Vznikly složky `AREAS/<skupina>/<oblast>/`? Kde se zasekl? |
| 45–65 | Pokračuje onboarding: profil, pět vět, **první projekt**. | Před strukturou **nezaložil** projekt? Je název složky projektu podle pravidel? **Skončila každá odpověď Clauda výzvou k dalšímu kroku?** Když uživatel odbočil (třeba k profilu), vrátil se Claude větou „Vracím se ke kroku…“? |
| 65–75 | **Prohlídka skillů** (krok 6b): Claude ukáže dva až tři skilly na věcech uživatele, uživatel píše zkušební věty sám. Pak ať zkusí „Kde jsem skončil?“ | Psal věty sám, ne Claude za něj? Odebírá Claude ukázané skilly ze seznamu v `session-brain.md` (sekce Onboarding)? Zvládl to bez tvé nápovědy? Ptá se `file-guard` před novou složkou nebo smazáním? |
| 75–80 | Ať napíše: „Končím.“ (`session-close`). Vysvětli, že zítra na „Kde jsem skončil?“ navážou a že za pár dní Claude nabídne týdenní přehled „Jak používám systém?“. | Zapsal se `SYSTEM/registry/session-brain.md` a zůstala v něm sekce Onboarding (zbývající skilly, řádek Přehled používání s datem)? |

**Struktura je podmínka pro projekty.** Kdyby chtěl uživatel „rovnou založit projekt“, Claude by měl vysvětlit proč ne hned a projít strukturu. Když ne, poznamenej to: je to slabé místo.

## Když něco nejde

| Příznak | Co dělat |
|---|---|
| `CLAUDE.md` se nenačte | Řekni „Přečti Claude/CLAUDE.md“, poznamenej. Bez toho pravidla neplatí (`file-guard` nemá jiný způsob vynucení). |
| `.plugin` se nenainstaluje | Přejmenuj na `.zip` a nahraj znovu; pak `.skill` po jednom (**Customize** → **Skills** → **Upload skill**). Poznamenej, co aplikace hlásila. |
| Uživatel přetáhl soubory do okna chatu | Nic se nestalo, jen se nic nenainstalovalo a vzalo to kus limitu. Vrať ho k nahrání přes Customize. Poznamenej: README to zřejmě neříká dost jasně. |
| Skript nejde spustit (chybí Python nebo bash) | Skill přejde na ruční postup a řekne to. Poznamenej, kterého skriptu se to týkalo. |
| Uživatel oblasti nechápe nebo jich chce deset | Vrať se k otázce „Jaké velké oblasti má tvůj život nebo práce?“ Stačí tři. Nová oblast jde přidat později, ale jen po dohodě. |
| Claude po onboardingu neví, kde jsi skončil | Zkontroluj, jestli existuje `SYSTEM/registry/session-brain.md` a co obsahuje (sekce Onboarding: co je `hotovo` a co `zbývá`). Poznamenej. |
| Claude skončí krok a nic dalšího neřekne | Napiš „Co dál?“ a poznamenej si, u kterého kroku to bylo: je to chyba vedení, opraví se ve skillu. |
| Uživatel se ztratí | Nevysvětluj skill. Vrať ho k pěti větám ze `START-HERE.md`. |

## Den poté (2 minuty, zpráva nebo telefon)

1. Napsal(a) „Kde jsem skončil?“ a odpověď seděla? Nabídl Claude zbývající skilly z prohlídky (nebo zbývající krok onboardingu)?
2. Zeptal se `file-guard` na něco (smazání, nová složka)?
3. Co ho zaskočilo nebo zdrželo?

## Co neslibovat

- **Nadstavbu a Pokročilé** (znalostní báze, přehledy, koučování, tvorba vlastních skillů) — přijdou později.
- Že týdenní přehled poběží sám i na bezplatném plánu. Naplánované úlohy jsou jen na placených plánech; jinak přijde připomínka a přehled se udělá v chatu.
- Že je to bez chyb. Je to první zkouška.
- Že je to záloha. `basic-security-guard` doporučí zálohu složky `Claude/`, ale nedělá ji.

## Po session (ty)

Zapiš, jak dopadl každý bod zkoušky (`CLAUDE.md` načten / plugin nainstalován / **struktura domluvena a pojmenování zvládnuto** / onboarding dokončen / příští den správně / skripty běží), a co je třeba změnit. Vyhodnocení pak jde do evidence projektu a určí, co se opraví před další distribucí.

## Soukromí

Profil a projekty uživatele patří jemu. Do sady se nekopírují a bez jeho souhlasu je nikam neposílej.
