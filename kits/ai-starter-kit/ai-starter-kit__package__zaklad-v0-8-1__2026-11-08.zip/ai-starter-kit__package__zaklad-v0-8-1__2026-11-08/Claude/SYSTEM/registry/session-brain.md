---
updated: RRRR-MM-DD
session: "jedna věta: co se dělalo"
---

# Předání (session-brain)

Krátká poznámka pro příští práci. Píše `session-close`, čte se jako první. Drž ji na jednu obrazovku (do ~40 řádků); starší věci patří do `log.md` projektu.

## Kde jsme
<co se dokončilo, co běží — pár vět>

## Horké projekty
- <projekt> — <stav a další krok>

## Pamatuj
- <věc, kterou by příště bylo snadné zapomenout>

## Otevřeno
- <nedořešené rozhodnutí nebo otázka>

## Next action
<první věc, kterou udělat příště>

## Onboarding
_Kontrolní seznam, zapisuje `onboarding` po každém kroku (`zbývá` → `hotovo`). Díky němu jde onboarding kdykoli přerušit a příště navázat. `session-close` ho nemaže._
- Kroky 1–1d (složka, záloha, systém, jazyk, soukromí): zbývá
- Krok 2 a 2b (pravidla, co už máš): zbývá
- Krok 3 (struktura, oblasti, pojmenování): zbývá
- Krok 3g (staré soubory): zbývá
- Krok 4 (profil): zbývá
- Krok 5 (pět vět): zbývá
- Krok 6 (první projekt): zbývá
- Krok 6b (prohlídka skillů): zbývá — idea-inbox, triage, session-close, file-guard, prompt-coach, token-economy, basic-security-guard, wiki, skill-builder
- Krok 7 (předání): zbývá
- Přehled používání: navrhnout od RRRR-MM-DD
