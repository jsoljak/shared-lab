---
type: registry
version: 0.8.1
visibility: PUBLIC
status: live
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 0.8.1

# Verze kitu

Říká, na jaké verzi kitu je **tvoje složka**. Podle toho `onboarding` pozná, co je potřeba při aktualizaci doplnit nebo přesunout. Zapisuje ho Claude, ne ty.

**Verze složky:** 0.8.1
**Naposledy upraveno:** 2026-11-08 (sestaveno)

## Historie aktualizací

| Datum | Z verze | Na verzi | Co se změnilo | Záloha |
|---|---|---|---|---|
| 2026-11-08 | (nová složka) | 0.8.1 | založeno ze šablony | nepotřeba |
