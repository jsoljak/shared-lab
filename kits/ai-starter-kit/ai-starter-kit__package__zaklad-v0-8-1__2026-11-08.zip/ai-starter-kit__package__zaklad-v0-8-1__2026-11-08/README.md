> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-11-08

# AI Starter Kit — Základ

Startovní sada pro práci s Claudem v desktopové aplikaci (Cowork) pro lidi, kteří nejsou AI-kovaní. **Tohle je první vrstva, Základ: 13 skillů**, které stačí na to, abys postavil(a) cokoli (systém, proces nebo osobní projekt), uměl(a) se rozhodnout, zadat Claudovi dobrou práci a udělal(a) si vlastní skill. Rozšíření **Pokročilé** je samostatný balíček (od verze 0.7.0), Nadstavba přijde později.

Sada **ještě nebyla zkoušena na cizím účtu**. Skilly, jejich skripty i šablona byly zkontrolovány mimo aplikaci. Jestli se v aplikaci nainstalují a chovají se dobře, ukáže první asistovaná session. Postup je v `RUNBOOK.md`.

## Co je uvnitř

```
ai-starter-kit (balíček)/
├── README.md                ← tento soubor
├── RUNBOOK.md               ← postup asistované session (pro toho, kdo sadu předává)
├── WIKI-OBSIDIAN.md         ← návod na druhý mozek: wiki, Obsidian, Web Clipper
├── ai-starter-kit.plugin    ← 13 skillů najednou; nahrává se v aplikaci: Customize → Plugins → Upload plugin
├── skills-jednotlive/       ← totéž po jednom jako .skill (záložní cesta, když .plugin nejde)
└── Claude/                  ← šablona pracovní složky (zkopírovat uživateli do Dokumentů)
    ├── CLAUDE.md · START-HERE.md · PROFILE.md      ← pravidla, pět vět, profil (kořen)
    ├── INBOX/               ← rychlé zápisy
    ├── PROJECTS/            ← věci s cílem a koncem (Projects)
    ├── AREAS/               ← trvalé oblasti (Areas); skupiny work · school · personal vzniknou při onboardingu
    ├── RESOURCES/           ← znalosti a zdroje (Resources)
    ├── ARCHIVE/             ← hotové a odložené (Archive)
    └── SYSTEM/              ← vše, co spravuje Claude
        ├── registry/            ← folder-map, workspace-rules, project-method, projects-registry,
        │                          decisions-registry, skills-catalog, session-brain, kit-version
        ├── skill-memory/        ← paměť skillů
        └── skills/              ← zdroje vlastních skillů (vznikne až později)
```

**Pravidlo psaní:** VELKÁ PÍSMENA = kostra, na kterou nesahám. malá písmena = to, co tvořím. Projekty si člověk při onboardingu zvolí buď v jedné vrstvě (`PROJECTS/`, doporučeno), nebo pod oblastí.

## Který skill na projekt? (nemusíš vybírat, rozhodne to Claude)

| Bude to… | Příklady | Skill | Vede |
|---|---|---|---|
| **fungovat dál a měnit se** | domácí síť, evidence záruk, rodinný kalendář, zahrada | `workspace-architect` | mapu: co z čeho se skládá |
| **proběhnout a skončit** | rekonstrukce, stěhování, výlet, svatba, plán studia | `project-planner` | plán: fáze, kdo, rozhodnutí |

Napíšeš „Chci založit projekt…“ a Claude se zeptá jednou: „Bude to fungovat dál a měnit se, nebo to proběhne a skončí?“ Přehled všech projektů a kontrolu najdeš u `workspace-architect`.

## Třináct skillů Základu

| Skill | K čemu |
|---|---|
| `onboarding` | první spuštění: **nejdřív složky, mapa a pojmenování**, potom profil, první projekt a prohlídka skillů; vede tě celou dobu a pamatuje si, kde jsi skončil |
| `workspace-architect` | projekty typu systém (mapa, stav částí, „kde jsem skončil“) a pohled přes všechny projekty: přehled, kontrola konzistence, „už to někde běží?“ |
| `project-planner` | projekty typu proces: fáze, kdo je zapojen, rozhodovací body |
| `cleanup` | uklidí složku, převezme tvé staré soubory do nové struktury (po dávkách, jde vrátit) |
| `file-guard` | kam soubor uložit, jak ho pojmenovat (i podle tvých oblastí), ptá se před rizikem |
| `triage` | roztřídí hromadu úkolů a nápadů (a obsah `INBOX/`) do projektů, oblastí a znalostí; nic nemaže, zapisuje po tvém souhlasu |
| `wiki` | druhý mozek: ukládá zdroje do `RESOURCES/`, píše z nich propojené stránky a odpovídá jen z nich; čte se i v Obsidianu (návod `WIKI-OBSIDIAN.md`) |
| `idea-inbox` | zachytí nápad nebo úkol do 30 sekund |
| `session-close` | konec práce: předání, kde jsi skončil |
| `basic-security-guard` | co nevkládat, zálohy, nastavení soukromí, kontrola složky na hesla a čísla karet, kontrola staženého souboru nebo cizího skillu na skryté pokyny pro AI |
| `prompt-coach` | pomůže napsat dobré zadání (prompt) pro Claude a vysvětlí proč. |
| `skill-builder` | vytvoří, upraví a zkontroluje tvůj vlastní skill podle pravidel kvalitního návrhu |
| `token-economy` | poradí, na jakém modelu Claude (Haiku, Sonnet, Opus) úkol pustit, ať zbytečně nevyčerpáš limit předplatného |

Skilly z dalších vrstev (`snapshot`, `catalog`, `work-graph`) jsou v některých dokumentech zmíněny. Dokud je nemáš, jejich práci dělá Claude jednodušeji sám, nebo se přeskočí. **Pokročilé** jsou samostatný balíček, rozšíření Základu pro víc projektů najednou; co přidávají a kdy je ještě nepotřebuješ, je v jejich README.

**Chceš všechno anglicky?** Napiš Claudovi „Chci všechno anglicky“ (nebo „Switch everything to English“). `onboarding` převede profil, úvodní soubor a skilly, předem řekne, co nechá česky, a vše zazálohuje. Po aktualizaci kitu převod nabídne znovu.

## Jak to nainstalovat a rozjet (Mac i Windows)

**Co potřebuješ:** desktopovou aplikaci Claude (Cowork) staženou z claude.ai/download (ne z App Storu) a přihlášený účet. Python není nutný (skripty pouští Claude).

**Nejdřív jedno pravidlo: nic z tohoto balíčku nedávej do okna chatu.** Zip, `.plugin` ani `.skill` nepřetahuj do konverzace s Claudem a nepřikládej ke zprávě. Claude by je jen četl, nic by se nenainstalovalo a bralo by to limit předplatného. Soubory kopíruješ ve Finderu (Mac) nebo v Průzkumníku (Windows), plugin nahráváš v nastavení aplikace. Do okna chatu jen píšeš věty.

Tenhle soubor čteš z rozbalené složky ve **Stažených**. Tam taky všechno zůstane, jen dvě věci půjdou jinam:

| Co tu vidíš | Co s tím uděláš |
|---|---|
| složka `Claude` | zkopíruješ do Dokumentů (krok 2) |
| soubor `ai-starter-kit.plugin` | nahraješ v aplikaci Claude (krok 4) |
| složka `skills-jednotlive` | nic, jen kdyby plugin nešel nahrát |
| `README.md`, `RELEASE-NOTES.md`, `RUNBOOK.md`, `WIKI-OBSIDIAN.md` | nic, jsou to návody ke čtení |

1. **Máš už složku `Claude` s vlastními soubory? Nejdřív ji zazálohuj** (Mac: pravý klik, **Komprimovat** · Windows: pravý klik, **Odeslat**, **Komprimovaná složka**) a pokračuj níž v části **Už máš vlastní složku**. Kroky 2 až 6 jsou pro toho, kdo začíná načisto.
2. **Zkopíruj jen složku `Claude` do Dokumentů.** Mac: ve Finderu klikni na složku `Claude`, **Cmd + C**, vlevo **Dokumenty**, **Cmd + V**. Windows: v Průzkumníku totéž s **Ctrl + C** a **Ctrl + V** (máš-li Dokumenty ve OneDrive, tak tam). Vznikne `Dokumenty/Claude`. Proč Dokumenty: většinou se zálohují samy (iCloud Drive nebo Time Machine, OneDrive nebo Historie souborů) a aplikace Claude pracuje se složkou `Dokumenty/Claude` sama. **Mac s iCloudem:** u složky `Claude` pravý klik, **Vždy ponechat na tomto zařízení**; iCloud ale není záloha, měj i jinou kopii. **Windows:** zapni si zobrazení přípon (**Zobrazit**, **Zobrazit**, **Přípony názvů souborů**).
3. **Nasdílej složku v aplikaci:** otevři novou konverzaci v **Coworku** a jako pracovní složku vyber **Dokumenty → Claude**. Ptá-li se macOS na přístup ke složce Dokumenty, povol.
4. **Nahraj skilly (v nastavení aplikace, ne v chatu):**
   1. V aplikaci klikni vlevo na **Customize** (máš-li přepínač Chat / Cowork, nejdřív **Cowork**).
   2. Záložka **Plugins** → **Add** → **Upload plugin**.
   3. V okně pro výběr souboru jdi do **Stažené**, otevři tuhle rozbalenou složku, vyber **`ai-starter-kit.plugin`** a klikni na **Otevřít**. Nahrává se jen tenhle soubor, ne celý stažený zip.
   4. Potvrď upozornění, že plugin nepochází od Anthropicu. Všech 13 skillů je nainstalovaných.
   - U nainstalovaného pluginu **neklikej na „Customize“**: spustí úkol pro Clauda a bere limit.
   - Aplikace soubor nevzala? Přejmenuj ho na `ai-starter-kit.zip` a nahraj znovu. Pořád nic? Po jednom: **Customize** → **Skills** → **+** → **Upload skill** a vyber soubor ze složky `skills-jednotlive`, 13×.
   - Názvy tlačítek se podle verze aplikace můžou trochu lišit. Hledej vždy **Customize** vlevo a v něm nahrání (Upload).
5. **Do okna chatu napiš:** „Začínám — spusť onboarding.“ Zeptá se na Mac nebo Windows, projde s tebou nastavení soukromí, zjistí, co už máš, navrhne složky a provede tě nastavením (asi hodina a čtvrt). Po každém kroku řekne, co bude dál; přestat můžeš kdykoli a příště napíšeš „Kde jsem skončil?“. Nic nesmaže bez tvého „ano“.
6. **Ověř:** napiš „Jaké skilly mám?“ (má jich být 13).

**Už máš vlastní složku, skilly nebo nastavení Clauda?** Nic nekopíruj přes ně, přepsalo by ti to tvoje soubory. Místo toho:
1. **Zazálohuj, co máš** (zazipuj složku, nebo ji zkopíruj jinam).
2. **Vytvoř složku `kit`:** otevři `Dokumenty` → `Claude` → `INBOX`, pravý klik do prázdného místa, nová složka, název `kit` (malými). Výsledek: `Dokumenty/Claude/INBOX/kit`. Víc podsložek nevytvářej.
3. **Zkopíruj do `kit` všechno z téhle rozbalené složky:** označ všechno (**Cmd + A** / **Ctrl + A**), **Cmd + C** / **Ctrl + C**, otevři `kit`, **Cmd + V** / **Ctrl + V**. Claude vidí jen složku `Claude`, ze Stažených nic nepřečte.
4. **Do okna chatu napiš:** „Podívej se na tenhle kit a poraď mi, jak by se dal zapojit do mého stávajícího prostředí. Provedeš mě tím podle onboardingu.“

Claude projde, co už máš (skilly, pravidla, seznamy, soubory), navrhne, co ponechat, co sloučit a co z kitu přidat, a provede tě tím po krocích, včetně nahrání pluginu. Před každou změnou se zeptá, nic nesmaže a tvůj `CLAUDE.md` obohatí o naše pravidla, ne přepíše. Můžeš cokoli odmítnout.

**Aktualizace, až vyjde nová verze:**
1. Nový zip rozbal ve **Stažených**.
2. Otevři `Dokumenty` → `Claude` → `INBOX`. Je-li tam složka `kit` ze starší verze, smaž ji. Vytvoř novou prázdnou `kit` a zkopíruj do ní všechno z nové rozbalené složky. Nic nekopíruj přímo do `Dokumenty/Claude`.
3. Nahraj nový plugin: **Customize** → **Plugins** → **Add** → **Upload plugin** → `ai-starter-kit.plugin` ze složky `kit`. Vidíš-li sadu dvakrát, starší odeber.
4. Do okna chatu napiš: „Aktualizuj kit.“ Podrobnosti jsou v `RELEASE-NOTES.md`.

## Nasazení ve zkratce (pro toho, kdo sadu předává)

1. Zkopíruj složku `Claude/` uživateli do `Dokumenty/` a nasdílej ji v aplikaci jako pracovní prostor.
2. Nahraj `ai-starter-kit.plugin` v aplikaci: **Customize** → **Plugins** → **Add** → **Upload plugin** (krok 4 výše). Do okna chatu ho nedávej. Nejde-li to, nahraj `.skill` soubory ze složky `skills-jednotlive/` po jednom (**Customize** → **Skills** → **Upload skill**).
3. Napiš Claudovi: **„Začínám — spusť onboarding.“** První, co spolu uděláte, je **struktura**: Claude se vás nejdřív empaticky zeptá na váš běžný týden a **navrhne hotovou kostru oblastí** (pracující, student, podnikatel, jiné), kterou si upravíte. Pak projdete složky (metoda PARA), mapu a pojmenování souborů. Až potom profil, první projekt a prohlídka skillů. Bez toho by se soubory zakládaly každý jinak a vznikl by bordel.

Podrobný postup s minutami, co sledovat a co dělat, když něco nejde, je v `RUNBOOK.md`.

## Známá omezení

- V aplikaci nejsou hooky ani git: `file-guard` nemá technické právo veta. Pravidla drží `CLAUDE.md` a skilly, a jen když se jimi Claude řídí.
- Skripty (kontrola názvů, konzistence, hesel, přehledy) vyžadují Python 3 a bash. Nejsou-li k dispozici, skilly přejdou na ruční postup a řeknou to.
- Instalovatelnost `.plugin` a načtení `CLAUDE.md` na cizím účtu jsou neověřené.
- Testovací věty skillů (`evals/`) v balíčku nejsou, byly to pracovní zkoušky autora.
