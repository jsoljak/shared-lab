> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 2026-10-01

# AI Starter Kit — Základ

Startovní sada pro práci s Claudem v desktopové aplikaci (Cowork) pro lidi, kteří nejsou AI-kovaní. **Tohle je první vrstva, Základ: 12 skillů**, které stačí na to, abys postavil(a) cokoli (systém, proces nebo osobní projekt), uměl(a) se rozhodnout, zadat Claudovi dobrou práci a udělal(a) si vlastní skill. Další vrstvy (Nadstavba a Pokročilé) přijdou později.

Sada **ještě nebyla zkoušena na cizím účtu**. Skilly, jejich skripty i šablona byly zkontrolovány mimo aplikaci. Jestli se v aplikaci nainstalují a chovají se dobře, ukáže první asistovaná session. Postup je v `RUNBOOK.md`.

## Co je uvnitř

```
ai-starter-kit (balíček)/
├── README.md                ← tento soubor
├── RUNBOOK.md               ← postup asistované session (pro toho, kdo sadu předává)
├── ai-starter-kit.plugin    ← 12 skillů najednou (hlavní cesta instalace)
├── skills-jednotlive/       ← totéž po jednom jako .skill (záložní cesta, když .plugin nejde)
└── Claude/                  ← šablona pracovní složky (zkopírovat uživateli do Dokumentů)
    ├── CLAUDE.md · START-HERE.md · PROFILE.md      ← pravidla, pět vět, profil (kořen)
    ├── INBOX/               ← rychlé zápisy
    ├── PROJECTS/            ← věci s cílem a koncem (Projects)
    ├── AREAS/               ← trvalé oblasti (Areas); skupiny work · school · personal vzniknou při onboardingu
    ├── RESOURCES/           ← znalosti a zdroje (Resources)
    ├── ARCHIVE/             ← hotové a odložené (Archive)
    └── SYSTEM/              ← vše, co spravuje Claude
        ├── registry/            ← folder-map, workspace-rules, project-method, projects-registry,
        │                          decisions-registry, skills-catalog, session-brain, kit-version
        ├── skill-memory/        ← paměť skillů
        └── skills/              ← zdroje vlastních skillů (vznikne až později)
```

**Pravidlo psaní:** VELKÁ PÍSMENA = kostra, na kterou nesahám. malá písmena = to, co tvořím. Projekty si člověk při onboardingu zvolí buď v jedné vrstvě (`PROJECTS/`, doporučeno), nebo pod oblastí.

**Už máš starší verzi kitu?** Nainstaluj nové skilly, rozbal nový balíček a napiš Claudovi „aktualizuj kit“. `onboarding` (režim AKTUALIZACE) složku zazálohuje, doplní, co je nového, a nic z tvého neztratí. Jedna cesta pro všechny verze.

## Který skill na projekt? (nemusíš vybírat, rozhodne to Claude)

| Bude to… | Příklady | Skill | Vede |
|---|---|---|---|
| **fungovat dál a měnit se** | domácí síť, evidence záruk, rodinný kalendář, zahrada | `workspace-architect` | mapu: co z čeho se skládá |
| **proběhnout a skončit** | rekonstrukce, stěhování, výlet, svatba, plán studia | `project-planner` | plán: fáze, kdo, rozhodnutí |

Napíšeš „Chci založit projekt…“ a Claude se zeptá jednou: „Bude to fungovat dál a měnit se, nebo to proběhne a skončí?“ Přehled všech projektů a kontrolu najdeš u `workspace-architect`.

## Dvanáct skillů Základu

| Skill | K čemu |
|---|---|
| `onboarding` | první spuštění: **nejdřív složky, mapa a pojmenování**, potom profil a první projekt |
| `workspace-architect` | projekty typu systém (mapa, stav částí, „kde jsem skončil“) a pohled přes všechny projekty: přehled, kontrola konzistence, „už to někde běží?“ |
| `project-planner` | projekty typu proces: fáze, kdo je zapojen, rozhodovací body |
| `cleanup` | uklidí složku, převezme tvé staré soubory do nové struktury (po dávkách, jde vrátit) |
| `file-guard` | kam soubor uložit, jak ho pojmenovat (i podle tvých oblastí), ptá se před rizikem |
| `triage` | roztřídí hromadu úkolů a nápadů (a obsah `INBOX/`) do projektů, oblastí a znalostí; nic nemaže, zapisuje po tvém souhlasu |
| `idea-inbox` | zachytí nápad nebo úkol do 30 sekund |
| `session-close` | konec práce: předání, kde jsi skončil |
| `basic-security-guard` | co nevkládat, zálohy, kontrola složky na hesla a čísla karet |
| `prompt-coach` | pomůže napsat dobré zadání (prompt) pro Claude a vysvětlí proč. |
| `skill-builder` | vytvoří, upraví a zkontroluje tvůj vlastní skill podle pravidel kvalitního návrhu |
| `token-economy` | poradí, na jakém modelu Claude (Haiku, Sonnet, Opus) úkol pustit, ať zbytečně nevyčerpáš limit předplatného |

Skilly z dalších vrstev (`wiki`, `snapshot`, `catalog`, `ai-builder`) jsou v některých dokumentech zmíněny. Dokud je nemáš, jejich práci dělá Claude jednodušeji sám, nebo se přeskočí.

## Jak to nainstalovat a rozjet (Mac i Windows)

**Co potřebuješ:** desktopovou aplikaci Claude (Cowork) a přihlášený účet. Python není nutný (skripty pouští Claude).

1. **Máš už složku `Claude` s vlastními soubory? Nejdřív ji zazálohuj.** Zazipuj ji (Mac: pravý klik, Komprimovat · Windows: pravý klik, Odeslat, Komprimovaná složka) nebo ji zkopíruj na jiné místo (jiný disk, flashka). Trvá to minutu a o nic nepřijdeš, ani kdyby se cokoli pokazilo.
2. **Rozbal** balíček (dvojklik na `.zip`).
3. **Zkopíruj složku `Claude/`** do Dokumentů (vznikne `Dokumenty/Claude`). Mac: označ ji a Cmd + C, v Dokumentech Cmd + V. Windows: Ctrl + C a Ctrl + V; máš-li Dokumenty ve OneDrive, kopíruj tam, kde je máš. **Windows:** v Průzkumníku si zapni zobrazení přípon souborů (Zobrazit, Zobrazit, Přípony názvů souborů). **Proč právě Dokumenty:** složka Dokumenty se většinou zálohuje sama: na Macu přes iCloud Drive (Plocha a Dokumenty) nebo Time Machine, ve Windows přes OneDrive (zálohování složek) nebo Historii souborů. Co leží v `Dokumenty/Claude`, je tedy i zazálohované. Máš-li složku `Claude` už jinde, nech ji tam, jen si ověř, že se zálohuje.
4. **Nasdílej složku** v aplikaci: otevři novou konverzaci a jako pracovní složku vyber `Claude`.
5. **Nainstaluj skilly:** otevři `ai-starter-kit.plugin` (dvojklik). Nejde-li to, nainstaluj soubory ze složky `skills-jednotlive/` po jednom.
6. **Napiš Claudovi:** „Začínám — spusť onboarding.“ Zeptá se na Mac nebo Windows, zjistí, co už máš, navrhne složky a provede tě nastavením (asi hodina). Nic nesmaže bez tvého „ano“.

**Už máš složku `Claude` s vlastními soubory?** Nejdřív ji zazálohuj (zazipuj, nebo zkopíruj jinam). Nekopíruj šablonu přes ni, přepsala by ti `CLAUDE.md`, profil a další soubory. Rozbal balíček vedle (třeba do `Dokumenty/Claude-kit`), zkopíruj ho celý do své složky `Claude/INBOX/prevzeti/kit/` a napiš Claudovi „Začínám — spusť onboarding.“ Vlastní pravidla neztratíš, `CLAUDE.md` se obohatí o naše, ne přepíše.

**Máš starší verzi?** Rozbal nový balíček, v aplikaci vypni staré přejmenované skilly (`guard`, `safety`, `inbox`, `model-advisor`, `coach`, `architect`, `planner`), nainstaluj nové a napiš Claudovi: „Aktualizuj kit.“ Podrobnosti jsou v `RELEASE-NOTES.md`.

## Nasazení ve zkratce (pro toho, kdo sadu předává)

1. Zkopíruj složku `Claude/` uživateli do `Dokumenty/` a nasdílej ji v aplikaci jako pracovní prostor.
2. Nainstaluj `ai-starter-kit.plugin` (klik na soubor v aplikaci). Nejde-li to, nainstaluj `.skill` soubory ze složky `skills-jednotlive/` po jednom.
3. Napiš Claudovi: **„Začínám — spusť onboarding.“** První, co spolu uděláte, je **struktura**: Claude se vás nejdřív empaticky zeptá na váš běžný týden a **navrhne hotovou kostru oblastí** (pracující, student, podnikatel, jiné), kterou si upravíte. Pak projdete složky (metoda PARA), mapu a pojmenování souborů. Až potom profil a první projekt. Bez toho by se soubory zakládaly každý jinak a vznikl by bordel.

Podrobný postup s minutami, co sledovat a co dělat, když něco nejde, je v `RUNBOOK.md`.

## Známá omezení

- V aplikaci nejsou hooky ani git: `file-guard` nemá technické právo veta. Pravidla drží `CLAUDE.md` a skilly, a jen když se jimi Claude řídí.
- Skripty (kontrola názvů, konzistence, hesel, přehledy) vyžadují Python 3 a bash. Nejsou-li k dispozici, skilly přejdou na ruční postup a řeknou to.
- Instalovatelnost `.plugin` a načtení `CLAUDE.md` na cizím účtu jsou neověřené.
- Testovací věty skillů (`evals/`) v balíčku nejsou, byly to pracovní zkoušky autora.
