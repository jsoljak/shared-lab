---
type: registry
version: 0.7.0
visibility: PUBLIC
status: live
---

> **visibility: PUBLIC | Distribution: LINK-ONLY**
> Author: Jiří Soljak | linkedin.com/in/jirisoljak
> Version: 0.7.0

# Verze kitu

Říká, na jaké verzi kitu je **tvoje složka**. Podle toho `onboarding` pozná, co je potřeba při aktualizaci doplnit nebo přesunout. Zapisuje ho Claude, ne ty.

**Verze složky:** 0.7.0
**Naposledy upraveno:** 2026-10-22 (sestaveno)

## Historie aktualizací

| Datum | Z verze | Na verzi | Co se změnilo | Záloha |
|---|---|---|---|---|
| 2026-10-22 | (nová složka) | 0.7.0 | založeno ze šablony | nepotřeba |
